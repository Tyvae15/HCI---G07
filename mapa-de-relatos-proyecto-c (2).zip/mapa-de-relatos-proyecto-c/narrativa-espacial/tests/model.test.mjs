/**
 * Pruebas del modelo (sin navegador). Ejecutar:  npm test
 * Verifican las reglas de colaboración: versiones, conflictos, borrado
 * reversible, rutas y tolerancia a errores en los códigos.
 */
import assert from 'node:assert/strict';
import {
  applyOp, findNodeByCode, suggestNodesByCode, routeProgress,
  contributionPoints, readersOf, distanceMeters, activeFragments
} from '../public/js/model.js';
import { seedState } from '../public/js/seed.js';

let n = 0;
const op = (type, by, payload) => ({ id: `t${n++}`, type, by, at: new Date().toISOString(), payload });
const test = (name, fn) => { fn(); console.log('✔', name); };

test('el seed se construye sin errores', () => {
  const s = seedState();
  assert.equal(Object.keys(s.nodes).length, 4);
  assert.ok(s.rev > 0);
});

test('conflicto cuando dos personas editan el mismo fragmento', () => {
  const s = seedState();
  const frag = s.nodes.n_plaza.fragments[0];
  const base = frag.version;
  // Ana guarda primero…
  assert.equal(applyOp(s, op('fragment.edit', 'u_ana', { nodeId: 'n_plaza', fragmentId: frag.id, baseVersion: base, text: 'Versión de Ana' })).ok, true);
  // …Luis guarda con la versión vieja → conflicto, y el texto de Ana NO se pisa.
  const r = applyOp(s, op('fragment.edit', 'u_luis', { nodeId: 'n_plaza', fragmentId: frag.id, baseVersion: base, text: 'Versión de Luis' }));
  assert.equal(r.ok, false);
  assert.equal(r.error, 'conflicto');
  assert.equal(r.conflict.current.text, 'Versión de Ana');
  assert.equal(s.nodes.n_plaza.fragments[0].history.length, 1);
});

test('borrar y deshacer un nodo', () => {
  const s = seedState();
  applyOp(s, op('node.delete', 'u_ana', { id: 'n_puente' }));
  assert.equal(findNodeByCode(s, 'BRC2'), null);
  applyOp(s, op('node.restore', 'u_ana', { id: 'n_puente' }));
  assert.equal(findNodeByCode(s, 'brc-2').id, 'n_puente');
});

test('código con un error sugiere el nodo correcto', () => {
  const s = seedState();
  assert.equal(findNodeByCode(s, 'BRC3'), null);
  assert.equal(suggestNodesByCode(s, 'BRC3')[0].id, 'n_puente');
});

test('una ruta necesita al menos 2 nodos', () => {
  const s = seedState();
  const r = applyOp(s, op('route.create', 'u_ana', { id: 'r_x', storyId: 's_barranco', name: 'X', nodeIds: ['n_plaza'] }));
  assert.equal(r.error, 'ruta-corta');
});

test('progreso de ruta y lectores', () => {
  const s = seedState();
  const p = routeProgress(s, 'u_luis', s.routes.r_carta);
  assert.deepEqual([p.done, p.total, p.nextIndex], [2, 4, 2]);
  assert.equal(readersOf(s, 'n_plaza')[0].user.name, 'Luis');
  // Marcar dos veces no duplica ni sube la revisión.
  const rev = s.rev;
  applyOp(s, op('read.mark', 'u_luis', { nodeId: 'n_plaza', via: 'qr' }));
  assert.equal(s.rev, rev);
});

test('puntos de partida para nuevos autores', () => {
  const s = seedState();
  const ids = contributionPoints(s, 's_barranco').map(x => x.node.id);
  assert.ok(ids.includes('n_malecon')); // abierto, vacío y final de ruta
});

test('fragmento de texto vacío es rechazado', () => {
  const s = seedState();
  const r = applyOp(s, op('fragment.add', 'u_ana', { nodeId: 'n_plaza', fragment: { id: 'fx', kind: 'text', text: '   ' } }));
  assert.equal(r.error, 'texto-vacio');
  assert.equal(activeFragments(s.nodes.n_plaza).length, 2);
});

test('distancia Haversine razonable', () => {
  const d = distanceMeters({ lat: -12.14870, lng: -77.02065 }, { lat: -12.14905, lng: -77.02212 });
  assert.ok(d > 140 && d < 180, `distancia ${d}`);
});

console.log('\nTodas las pruebas pasaron.');
