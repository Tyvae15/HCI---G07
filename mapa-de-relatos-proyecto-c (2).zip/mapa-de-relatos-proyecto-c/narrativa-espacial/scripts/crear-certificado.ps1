# crear-certificado.ps1 — Certificado HTTPS de desarrollo (autofirmado)
# ----------------------------------------------------------------------------
# Para que el CELULAR pueda usar la cámara (escanear QR) y el GPS, el navegador
# exige HTTPS. Este script crea cert/dev.pfx con las IP de esta PC; al iniciar,
# server.mjs lo detecta y abre también https://IP:3443.
#
# Uso (desde la carpeta narrativa-espacial):
#   powershell -ExecutionPolicy Bypass -File scripts\crear-certificado.ps1
# Volver a ejecutarlo si cambia la IP de la PC (otra red Wi-Fi).

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$outDir = Join-Path $root 'cert'
$pfx = Join-Path $outDir 'dev.pfx'
$pass = 'mapa'  # solo protege el archivo local; debe coincidir con server.mjs

# IPs de la red local (sin adaptadores virtuales ni direcciones automáticas 169.254.x).
$ips = Get-NetIPAddress -AddressFamily IPv4 |
  Where-Object { $_.IPAddress -notlike '169.254.*' -and $_.InterfaceAlias -notmatch 'vmware|virtualbox|vethernet|wsl|docker|bluetooth' } |
  ForEach-Object IPAddress
$san = (@('DNS=localhost') + ($ips | ForEach-Object { "IPAddress=$_" })) -join '&'

$cert = New-SelfSignedCertificate -Subject 'CN=Mapa de Relatos (desarrollo)' `
  -TextExtension @("2.5.29.17={text}$san") `
  -KeyAlgorithm RSA -KeyLength 2048 -HashAlgorithm SHA256 -KeyExportPolicy Exportable `
  -NotAfter (Get-Date).AddYears(1) -CertStoreLocation 'Cert:\CurrentUser\My'

New-Item -ItemType Directory -Force $outDir | Out-Null
$secure = ConvertTo-SecureString $pass -AsPlainText -Force
Export-PfxCertificate -Cert $cert -FilePath $pfx -Password $secure -CryptoAlgorithmOption AES256_SHA256 | Out-Null
Remove-Item "Cert:\CurrentUser\My\$($cert.Thumbprint)"  # no se deja instalado en Windows

Write-Host "Certificado creado: $pfx"
Write-Host "Valido para: $($san -replace '&', ', ')"
Write-Host 'Reinicia el servidor (npm start) y abre en el celular la direccion https que muestra.'
