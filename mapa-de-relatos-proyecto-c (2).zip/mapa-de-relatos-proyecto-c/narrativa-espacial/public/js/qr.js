/**
 * qr.js — ANCLAJE FÍSICO CON CÓDIGOS QR (con tolerancia a errores)
 * ----------------------------------------------------------------------------
 * Reto HCI: "QR dañado, mal escaneado o sin señal". Por eso hay CUATRO
 * caminos para llegar al mismo nodo, del más rápido al más robusto:
 *   1) Escanear el QR con la CÁMARA DEL CELULAR (fuera de la app): el QR
 *      contiene un enlace ?n=CÓDIGO que abre la app directo en el nodo.
 *   2) Escanear dentro de la app (BarcodeDetector o jsQR).
 *   3) Subir/tomar una FOTO del QR (sirve aunque la cámara en vivo falle).
 *   4) Escribir el CÓDIGO CORTO impreso bajo el QR (4 letras, sin 0/O/1/I);
 *      si hay un error de 1 letra, se sugiere el código correcto.
 * El QR usa corrección de errores nivel H (~30% del código puede dañarse).
 */
import { esc, openDialog, track } from './ui.js';
import { normalizeCode } from './model.js';

// Si la app se abrió como "localhost", ese nombre no sirve en el celular
// (ahí "localhost" es el propio celular). Se pide al servidor su IP de red.
let shareOrigin = location.origin;
if (/^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname)) {
  fetch('/api/ping').then(r => r.json())
    .then(d => { if (d && d.publicUrl) shareOrigin = d.publicUrl; })
    .catch(() => { /* sin servidor: se queda con location.origin */ });
}

/** Enlace que va dentro del QR. */
export function nodeUrl(code) {
  return `${shareOrigin}${location.pathname}?n=${encodeURIComponent(code)}`;
}

/** Devuelve el SVG del QR (o un aviso si la librería no cargó). */
export function qrSvg(text) {
  if (typeof window.qrcode !== 'function') {
    return '<p class="muted">No se pudo generar el QR (sin conexión). Usa el código corto.</p>';
  }
  const qr = window.qrcode(0, 'H'); // 0 = tamaño automático, H = máxima corrección de errores
  qr.addData(text);
  qr.make();
  return qr.createSvgTag({ cellSize: 6, margin: 2, scalable: true });
}

/** Extrae el código de lo que leyó el escáner: un enlace con ?n=… o el código suelto. */
export function parseScanned(text) {
  try {
    const u = new URL(text);
    const n = u.searchParams.get('n');
    if (n) return normalizeCode(n);
  } catch { /* no era un enlace */ }
  return normalizeCode(text);
}

/** Diálogo con el QR de un nodo (para mostrar o imprimir). */
export function showNodeQr(node, onPrint) {
  return openDialog(`
    <h2 id="dialog-title">QR de “${esc(node.title)}”</h2>
    <p class="muted small">Imprímelo y pégalo en ${esc(node.place || 'el lugar')}. Quien lo escanee abrirá este nodo.</p>
    <div class="qr-box">
      ${qrSvg(nodeUrl(node.code))}
      <div class="qr-code-big" aria-label="Código ${esc(node.code.split('').join(' '))}">${esc(node.code)}</div>
      <p class="small muted">Si el QR se daña, se puede escribir este código en “Ingresar código”.</p>
    </div>
    <div class="dialog__actions">
      <button class="btn btn--ghost" data-close>Cerrar</button>
      <button class="btn" id="qr-print">🖨️ Imprimir</button>
    </div>`, (root, close) => root.querySelector('#qr-print').addEventListener('click', () => { close(); onPrint([node]); }));
}

/** Llena la hoja de impresión con una tarjeta por nodo y abre el diálogo de impresión. */
export function printQrSheet(nodes, storyTitle) {
  const area = document.getElementById('print-area');
  area.innerHTML = nodes.map(n => `
    <div class="print-card">
      <h3>${esc(storyTitle)}</h3>
      <p><strong>${esc(n.title)}</strong><br>${esc(n.place || '')}</p>
      ${qrSvg(nodeUrl(n.code))}
      <div class="qr-code-big">${esc(n.code)}</div>
      <p>Escanea con la cámara de tu celular o escribe el código en la app “Mapa de Relatos”.</p>
    </div>`).join('');
  setTimeout(() => window.print(), 100);
}

// --------------------------------------------------------------- Escáner
/** Intenta leer un QR desde una imagen/canvas/video. Devuelve el texto o null. */
async function detect(source, canvas) {
  // 1) API nativa (Chrome Android, Edge…): rápida y eficiente.
  if ('BarcodeDetector' in window) {
    try {
      const det = new window.BarcodeDetector({ formats: ['qr_code'] });
      const codes = await det.detect(source);
      if (codes.length) return codes[0].rawValue;
      return null;
    } catch { /* si falla, se intenta con jsQR */ }
  }
  // 2) jsQR: funciona en cualquier navegador analizando los píxeles.
  if (typeof window.jsQR !== 'function') return null;
  const w = source.videoWidth || source.width;
  const h = source.videoHeight || source.height;
  if (!w || !h) return null;
  const scale = Math.min(1, 800 / Math.max(w, h)); // reducir = más rápido
  canvas.width = Math.round(w * scale);
  canvas.height = Math.round(h * scale);
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
  const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const res = window.jsQR(img.data, img.width, img.height, { inversionAttempts: 'attemptBoth' });
  return res?.data || null;
}

/**
 * Abre el escáner. `lookup(code)` devuelve {node} si existe o {suggestions:[…]}.
 * `startWith`: 'camera' o 'code' (enfoca directamente el campo de texto).
 * Resuelve con {node, via:'qr'|'codigo'} o null si se cancela.
 */
export function openScanner({ lookup, startWith = 'camera', expected = null }) {
  const camSupported = Boolean(navigator.mediaDevices?.getUserMedia);
  let stream = null;
  let raf = null;

  return openDialog(`
    <h2 id="dialog-title">${startWith === 'code' ? 'Ingresar código del lugar' : 'Escanear código QR'}</h2>
    ${expected ? `<p class="muted small">Siguiente parada: <strong>${esc(expected.title)}</strong> · ${esc(expected.place || '')}</p>` : ''}
    <div id="scan-cam" ${startWith === 'code' ? 'hidden' : ''}>
      <video class="scanner-video" id="scan-video" playsinline muted aria-label="Vista de la cámara"></video>
      <p id="scan-msg" class="small muted" role="status">Apunta la cámara al código QR del lugar.</p>
      <label class="btn btn--ghost btn--block" style="margin-top:6px">
        📷 Tomar o subir una foto del QR
        <input type="file" id="scan-file" accept="image/*" capture="environment" hidden>
      </label>
    </div>
    <form id="scan-form" novalidate>
      <div class="field">
        <label for="scan-code">¿El QR no funciona? Escribe el código impreso</label>
        <input type="text" id="scan-code" inputmode="text" autocomplete="off" autocapitalize="characters"
               maxlength="8" placeholder="Ej.: BRC2" aria-describedby="scan-help" ${startWith === 'code' ? 'autofocus' : ''}>
        <span class="help" id="scan-help">Son 4 caracteres, debajo del QR. No importan mayúsculas ni guiones.</span>
        <span class="error" role="alert"></span>
      </div>
      <div id="scan-suggest"></div>
      <div class="dialog__actions">
        <button type="button" class="btn btn--ghost" data-close>Cancelar</button>
        <button type="submit" class="btn">Abrir nodo</button>
      </div>
    </form>
    <canvas id="scan-canvas" hidden></canvas>`,
  (root, close) => {
    const video = root.querySelector('#scan-video');
    const canvas = root.querySelector('#scan-canvas');
    const msg = root.querySelector('#scan-msg');
    const input = root.querySelector('#scan-code');
    const suggest = root.querySelector('#scan-suggest');
    const errorEl = root.querySelector('.error');

    // Apaga la cámara al cerrar el diálogo (privacidad y batería).
    const stop = () => { cancelAnimationFrame(raf); stream?.getTracks().forEach(t => t.stop()); };
    root.addEventListener('dialog-closed', stop, { once: true });

    // Resuelve un código leído o escrito.
    const tryCode = (raw, via) => {
      const code = parseScanned(raw);
      if (!code) { errorEl.textContent = 'Escribe el código del lugar.'; input.setAttribute('aria-invalid', 'true'); return false; }
      const r = lookup(code);
      if (r.node) { track('code-ok', { via }); close({ node: r.node, via }); return true; }
      track('error', { what: 'codigo-no-encontrado', code });
      input.value = code;
      input.setAttribute('aria-invalid', 'true');
      errorEl.textContent = `No encontramos el código “${code}”.`;
      suggest.innerHTML = r.suggestions?.length
        ? `<p class="small">¿Quisiste decir…?</p>` + r.suggestions.map(n =>
          `<button type="button" class="list-item" data-id="${esc(n.id)}"><span class="code-chip">${esc(n.code)}</span>
             <span class="list-item__main"><strong>${esc(n.title)}</strong><span>${esc(n.place || '')}</span></span></button>`).join('')
        : '<p class="small muted">Revisa que sea el código de esta historia. Las letras O e I no se usan.</p>';
      suggest.querySelectorAll('[data-id]').forEach(b => b.addEventListener('click', () => {
        const n = r.suggestions.find(x => x.id === b.dataset.id);
        close({ node: n, via });
      }));
      return false;
    };

    root.querySelector('#scan-form').addEventListener('submit', e => { e.preventDefault(); tryCode(input.value, 'codigo'); });
    input.addEventListener('input', () => { input.setAttribute('aria-invalid', 'false'); errorEl.textContent = ''; });

    // Foto del QR → se analiza la imagen.
    root.querySelector('#scan-file').addEventListener('change', async e => {
      const file = e.target.files[0];
      if (!file) return;
      msg.textContent = 'Analizando la foto…';
      try {
        const bmp = await createImageBitmap(file);
        const text = await detect(bmp, canvas);
        if (text) tryCode(text, 'qr');
        else { msg.textContent = 'No se encontró un QR en la foto. Acércate más o escribe el código.'; track('error', { what: 'qr-foto' }); }
      } catch { msg.textContent = 'No se pudo leer la foto. Escribe el código impreso.'; }
    });

    if (startWith === 'code') return;
    if (!camSupported) { msg.textContent = 'Este navegador no permite usar la cámara aquí. Sube una foto del QR o escribe el código.'; return; }

    // Cámara en vivo (trasera de preferencia).
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false })
      .then(s => {
        stream = s;
        video.srcObject = s;
        return video.play();
      })
      .then(() => {
        const started = Date.now();
        let busy = false;
        let lastText = null; // evita repetir el mismo error 60 veces por segundo
        const loop = async () => {
          if (!busy && video.readyState >= 2) {
            busy = true;
            const text = await detect(video, canvas).catch(() => null);
            busy = false;
            if (text && text !== lastText) {
              lastText = text;
              if (tryCode(text, 'qr')) return;
            }
          }
          // Si tras 12 s no se detecta nada, se sugieren alternativas (no dejar al usuario atascado).
          if (Date.now() - started > 12000) msg.textContent = 'No logramos leer el QR. Mejora la luz, acércate o escribe el código de abajo.';
          raf = requestAnimationFrame(loop);
        };
        loop();
      })
      .catch(err => {
        track('error', { what: 'camara', name: err.name });
        msg.textContent = err.name === 'NotAllowedError'
          ? 'No diste permiso para usar la cámara. Puedes subir una foto del QR o escribir el código.'
          : 'La cámara no está disponible (se necesita HTTPS en el celular). Sube una foto o escribe el código.';
      });
  });
}
