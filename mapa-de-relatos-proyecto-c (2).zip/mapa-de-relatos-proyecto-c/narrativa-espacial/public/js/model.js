/**
 * model.js — MODELO DE DATOS Y REGLAS DE COLABORACIÓN
 * ----------------------------------------------------------------------------
 * Este archivo es "puro": no toca el DOM ni la red. Por eso lo usan tanto el
 * navegador (store.js) como el servidor (server.mjs). Así, las reglas de
 * versiones y conflictos son exactamente las mismas en ambos lados.
 *
 * Idea central: TODO cambio a la historia es una "operación" (op) con forma
 *   { id, type, by, at, payload }
 * y se aplica con applyOp(state, op). Si la op es inválida o choca con una
 * edición más reciente de otra persona, se devuelve un error/conflicto y el
 * estado NO se modifica.
 *
 * Reto HCI que atiende: "Colaboración asíncrona coherente" (varios autores en
 * el mismo nodo/ruta, conflictos versionados, atribución y "ruta leída").
 */

// Alfabeto de los códigos cortos de nodo. Se excluyen 0/O y 1/I porque se
// confunden al leerlos de un cartel impreso (prevención de errores, Nielsen #5).
export const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export const CODE_LENGTH = 4;

/** Paleta de colores para autores (todas con contraste ≥ 4.5:1 sobre blanco). */
export const AUTHOR_COLORS = ['#0b5cad', '#b45309', '#15803d', '#7c3aed', '#be123c', '#0f766e', '#4338ca', '#a16207'];

/** Estado vacío. Las colecciones son objetos indexados por id para fusionar fácil. */
export function emptyState() {
  return {
    schema: 1,
    rev: 0,          // número de revisión global: sube con cada op aplicada
    users: {},       // { id: {id, name, color, createdAt} }
    stories: {},     // { id: {id, title, description, center, createdBy, createdAt} }
    nodes: {},       // { id: Nodo }  (ver createNode)
    routes: {},      // { id: Ruta }
    reads: {},       // { userId: { nodeId: {at, via} } }  → seguimiento de "ruta leída"
    log: []          // actividad reciente (para que cada autor vea lo que hicieron otros)
  };
}

/** Genera un id único legible (prefijo + tiempo + azar). */
export function uid(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

/** Genera un código corto aleatorio con el alfabeto sin caracteres ambiguos. */
export function randomCode() {
  let c = '';
  for (let i = 0; i < CODE_LENGTH; i++) c += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
  return c;
}

/**
 * Normaliza lo que el usuario escribe o lo que lee el escáner:
 * mayúsculas, sin espacios ni guiones ("c7-kq" → "C7KQ"). Si aun así no
 * coincide (p. ej. escribió una O en vez de una Q), suggestNodesByCode()
 * propone el código más parecido.
 */
export function normalizeCode(raw) {
  return String(raw || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
}

/** Distancia de Levenshtein: cuántas letras hay que cambiar para pasar de a → b. */
export function levenshtein(a, b) {
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
  }
  return dp[a.length][b.length];
}

// ---------------------------------------------------------------------------
// CONSULTAS (lecturas del estado; no modifican nada)
// ---------------------------------------------------------------------------

/** Nodos visibles (no eliminados) de una historia. */
export function activeNodes(state, storyId) {
  return Object.values(state.nodes).filter(n => !n.deleted && (!storyId || n.storyId === storyId));
}

/** Rutas visibles de una historia. */
export function activeRoutes(state, storyId) {
  return Object.values(state.routes).filter(r => !r.deleted && (!storyId || r.storyId === storyId));
}

/** Fragmentos visibles de un nodo. */
export function activeFragments(node) {
  return (node?.fragments || []).filter(f => !f.deleted);
}

/** Busca un nodo por su código corto (exacto). */
export function findNodeByCode(state, code) {
  const c = normalizeCode(code);
  return Object.values(state.nodes).find(n => !n.deleted && n.code === c) || null;
}

/**
 * Tolerancia a errores del QR/código: si no hay coincidencia exacta, sugiere
 * los nodos cuyo código difiere en ≤ 1 carácter ("¿Quisiste decir…?").
 */
export function suggestNodesByCode(state, code, maxDistance = 1) {
  const c = normalizeCode(code);
  if (!c) return [];
  return Object.values(state.nodes)
    .filter(n => !n.deleted)
    .map(n => ({ node: n, d: levenshtein(c, n.code) }))
    .filter(x => x.d <= maxDistance)
    .sort((a, b) => a.d - b.d)
    .map(x => x.node);
}

/** ¿El usuario ya leyó (desbloqueó) este nodo? */
export function hasRead(state, userId, nodeId) {
  return Boolean(state.reads?.[userId]?.[nodeId]);
}

/** Lista de usuarios que leyeron un nodo (para mostrar "Leído por…"). */
export function readersOf(state, nodeId) {
  return Object.entries(state.reads || {})
    .filter(([, nodes]) => nodes[nodeId])
    .map(([userId, nodes]) => ({ user: state.users[userId], at: nodes[nodeId].at, via: nodes[nodeId].via }))
    .filter(r => r.user);
}

/** Progreso de un usuario en una ruta: {done, total, pct, nextIndex}. */
export function routeProgress(state, userId, route) {
  const ids = (route?.nodeIds || []).filter(id => state.nodes[id] && !state.nodes[id].deleted);
  const done = ids.filter(id => hasRead(state, userId, id)).length;
  const nextIndex = ids.findIndex(id => !hasRead(state, userId, id));
  return { done, total: ids.length, pct: ids.length ? Math.round((done / ids.length) * 100) : 0, nextIndex };
}

/** Rutas que pasan por un nodo, con la posición del nodo en cada una. */
export function routesThrough(state, nodeId) {
  return Object.values(state.routes)
    .filter(r => !r.deleted && r.nodeIds.includes(nodeId))
    .map(r => ({ route: r, position: r.nodeIds.indexOf(nodeId) + 1 }));
}

/**
 * "Puntos de partida" para nuevos autores (Pregunta de investigación 1):
 * nodos marcados como abiertos, nodos con pocos fragmentos y finales de ruta.
 * Responde al problema del enunciado: "los nuevos autores no encuentran un
 * punto de partida claro".
 */
export function contributionPoints(state, storyId) {
  const routeEnds = new Set(activeRoutes(state, storyId).map(r => r.nodeIds[r.nodeIds.length - 1]));
  return activeNodes(state, storyId)
    .map(n => {
      const count = activeFragments(n).length;
      const reasons = [];
      if (n.open) reasons.push('El autor invita a continuar');
      if (count <= 1) reasons.push(count === 0 ? 'Aún sin fragmentos' : 'Solo tiene 1 fragmento');
      if (routeEnds.has(n.id)) reasons.push('Es el final de una ruta');
      return { node: n, reasons };
    })
    .filter(x => x.reasons.length)
    .sort((a, b) => b.reasons.length - a.reasons.length);
}

/** Distancia en metros entre dos coordenadas (fórmula de Haversine). */
export function distanceMeters(a, b) {
  const R = 6371000;
  const toRad = d => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

// ---------------------------------------------------------------------------
// OPERACIONES (únicas funciones que modifican el estado)
// ---------------------------------------------------------------------------

/** Resultado de error estándar. */
function fail(error, extra = {}) {
  return { ok: false, error, ...extra };
}

/** Recorta y valida texto obligatorio. */
function requiredText(value, max) {
  const v = String(value ?? '').trim();
  return v && v.length <= max ? v : null;
}

/** Registra la op en la actividad reciente (máx. 150 entradas). */
function pushLog(state, op, ref) {
  state.log.push({ id: op.id, type: op.type, by: op.by, at: op.at, ...ref });
  if (state.log.length > 150) state.log.splice(0, state.log.length - 150);
}

/**
 * Aplica una operación al estado.
 * @returns {{ok:true, ref?:object} | {ok:false, error:string, conflict?:object}}
 *
 * Control de concurrencia OPTIMISTA: las ops de edición traen `baseVersion`
 * (la versión que el usuario tenía en pantalla cuando empezó a editar). Si
 * otra persona guardó antes, la versión actual es mayor → conflicto. Nadie
 * pierde su trabajo en silencio: la interfaz le muestra ambas versiones.
 */
export function applyOp(state, op) {
  if (!op || !op.type) return fail('op-invalida');
  if (!op.by && op.type !== 'user.upsert') return fail('sin-autor');
  const p = op.payload || {};
  const at = op.at || new Date().toISOString();
  let ref = {};

  switch (op.type) {
    // --- Usuarios (perfil simple para atribución; no es autenticación real) ---
    case 'user.upsert': {
      const name = requiredText(p.name, 40);
      if (!p.id || !name) return fail('nombre-invalido');
      const prev = state.users[p.id];
      state.users[p.id] = { id: p.id, name, color: p.color || prev?.color || AUTHOR_COLORS[0], createdAt: prev?.createdAt || at };
      ref = { userId: p.id };
      break;
    }

    // --- Historias ---
    case 'story.create': {
      const title = requiredText(p.title, 80);
      if (!p.id || !title) return fail('titulo-invalido');
      if (state.stories[p.id]) return fail('ya-existe');
      state.stories[p.id] = {
        id: p.id, title, description: String(p.description || '').slice(0, 400),
        center: p.center || null, createdBy: op.by, createdAt: at
      };
      ref = { storyId: p.id };
      break;
    }

    // --- Nodos: un fragmento de la historia anclado a un lugar real ---
    case 'node.create': {
      const title = requiredText(p.title, 80);
      if (!p.id || !title) return fail('titulo-invalido');
      if (!state.stories[p.storyId]) return fail('historia-no-existe');
      if (!Number.isFinite(p.lat) || !Number.isFinite(p.lng)) return fail('ubicacion-invalida');
      if (state.nodes[p.id]) return fail('ya-existe');
      // Código único: si el propuesto ya existe, se genera otro.
      let code = normalizeCode(p.code) || randomCode();
      while (Object.values(state.nodes).some(n => n.code === code)) code = randomCode();
      state.nodes[p.id] = {
        id: p.id, storyId: p.storyId, code,
        lat: p.lat, lng: p.lng, title, place: String(p.place || '').slice(0, 80),
        open: Boolean(p.open), // "invitar a continuar aquí"
        createdBy: op.by, createdAt: at, updatedBy: op.by, updatedAt: at,
        version: 1, deleted: false, fragments: []
      };
      ref = { nodeId: p.id, storyId: p.storyId };
      break;
    }

    case 'node.update': {
      const node = state.nodes[p.id];
      if (!node || node.deleted) return fail('nodo-no-existe');
      if (p.baseVersion !== undefined && p.baseVersion !== node.version) {
        return fail('conflicto', { conflict: { entity: 'node', current: node, yours: p.changes } });
      }
      const c = p.changes || {};
      if ('title' in c) {
        const t = requiredText(c.title, 80);
        if (!t) return fail('titulo-invalido');
        node.title = t;
      }
      if ('place' in c) node.place = String(c.place || '').slice(0, 80);
      if ('open' in c) node.open = Boolean(c.open);
      if ('lat' in c && 'lng' in c) {
        if (!Number.isFinite(c.lat) || !Number.isFinite(c.lng)) return fail('ubicacion-invalida');
        node.lat = c.lat; node.lng = c.lng;
      }
      node.version += 1; node.updatedBy = op.by; node.updatedAt = at;
      ref = { nodeId: node.id, storyId: node.storyId };
      break;
    }

    case 'node.delete':
    case 'node.restore': {
      // Borrado "suave": se marca y se puede deshacer (control y libertad, Nielsen #3).
      const node = state.nodes[p.id];
      if (!node) return fail('nodo-no-existe');
      node.deleted = op.type === 'node.delete';
      node.version += 1; node.updatedBy = op.by; node.updatedAt = at;
      ref = { nodeId: node.id, storyId: node.storyId };
      break;
    }

    // --- Fragmentos: texto, foto o audio dentro de un nodo ---
    case 'fragment.add': {
      const node = state.nodes[p.nodeId];
      if (!node || node.deleted) return fail('nodo-no-existe');
      const f = p.fragment || {};
      if (!f.id || !['text', 'photo', 'audio'].includes(f.kind)) return fail('fragmento-invalido');
      const text = String(f.text || '').trim().slice(0, 4000);
      if (f.kind === 'text' && !text) return fail('texto-vacio');
      if (f.kind !== 'text' && !String(f.media || '').startsWith('data:')) return fail('archivo-invalido');
      if (node.fragments.some(x => x.id === f.id)) return fail('ya-existe');
      node.fragments.push({
        id: f.id, kind: f.kind, text, media: f.kind === 'text' ? null : f.media,
        authorId: op.by, createdAt: at, updatedBy: op.by, updatedAt: at,
        version: 1, deleted: false, history: []
      });
      ref = { nodeId: node.id, storyId: node.storyId, fragmentId: f.id };
      break;
    }

    case 'fragment.edit': {
      const node = state.nodes[p.nodeId];
      const frag = node?.fragments.find(x => x.id === p.fragmentId);
      if (!frag || frag.deleted) return fail('fragmento-no-existe');
      if (p.baseVersion !== frag.version) {
        // Otra persona editó este fragmento mientras tú escribías.
        return fail('conflicto', { conflict: { entity: 'fragment', nodeId: node.id, current: frag, yours: { text: p.text } } });
      }
      const text = String(p.text || '').trim().slice(0, 4000);
      if (frag.kind === 'text' && !text) return fail('texto-vacio');
      // Se guarda la versión anterior en el historial (permite ver y restaurar).
      frag.history.push({ version: frag.version, text: frag.text, by: frag.updatedBy, at: frag.updatedAt });
      if (frag.history.length > 30) frag.history.shift();
      frag.text = text; frag.version += 1; frag.updatedBy = op.by; frag.updatedAt = at;
      ref = { nodeId: node.id, storyId: node.storyId, fragmentId: frag.id };
      break;
    }

    case 'fragment.delete':
    case 'fragment.restore': {
      const node = state.nodes[p.nodeId];
      const frag = node?.fragments.find(x => x.id === p.fragmentId);
      if (!frag) return fail('fragmento-no-existe');
      frag.deleted = op.type === 'fragment.delete';
      frag.version += 1; frag.updatedBy = op.by; frag.updatedAt = at;
      ref = { nodeId: node.id, storyId: node.storyId, fragmentId: frag.id };
      break;
    }

    // --- Rutas: secuencia ordenada de nodos (el "camino" de la historia) ---
    case 'route.create': {
      const name = requiredText(p.name, 60);
      if (!p.id || !name) return fail('nombre-invalido');
      if (!state.stories[p.storyId]) return fail('historia-no-existe');
      const ids = (p.nodeIds || []).filter(id => state.nodes[id] && !state.nodes[id].deleted);
      if (ids.length < 2) return fail('ruta-corta');
      state.routes[p.id] = {
        id: p.id, storyId: p.storyId, name, nodeIds: ids, color: p.color || '#0b5cad',
        createdBy: op.by, createdAt: at, updatedBy: op.by, updatedAt: at, version: 1, deleted: false
      };
      ref = { routeId: p.id, storyId: p.storyId };
      break;
    }

    case 'route.update': {
      const route = state.routes[p.id];
      if (!route || route.deleted) return fail('ruta-no-existe');
      if (p.baseVersion !== undefined && p.baseVersion !== route.version) {
        return fail('conflicto', { conflict: { entity: 'route', current: route, yours: p.changes } });
      }
      const c = p.changes || {};
      if ('name' in c) {
        const n = requiredText(c.name, 60);
        if (!n) return fail('nombre-invalido');
        route.name = n;
      }
      if ('nodeIds' in c) {
        const ids = c.nodeIds.filter(id => state.nodes[id] && !state.nodes[id].deleted);
        if (ids.length < 2) return fail('ruta-corta');
        route.nodeIds = ids;
      }
      route.version += 1; route.updatedBy = op.by; route.updatedAt = at;
      ref = { routeId: route.id, storyId: route.storyId };
      break;
    }

    case 'route.delete':
    case 'route.restore': {
      const route = state.routes[p.id];
      if (!route) return fail('ruta-no-existe');
      route.deleted = op.type === 'route.delete';
      route.version += 1; route.updatedBy = op.by; route.updatedAt = at;
      ref = { routeId: route.id, storyId: route.storyId };
      break;
    }

    // --- Lectura: el usuario desbloqueó/leyó un nodo (QR, GPS, código o remoto) ---
    case 'read.mark': {
      const node = state.nodes[p.nodeId];
      if (!node) return fail('nodo-no-existe');
      state.reads[op.by] = state.reads[op.by] || {};
      if (state.reads[op.by][p.nodeId]) return { ok: true, ref: { nodeId: p.nodeId }, noop: true };
      state.reads[op.by][p.nodeId] = { at, via: p.via || 'remoto' };
      ref = { nodeId: node.id, storyId: node.storyId };
      break;
    }

    default:
      return fail('tipo-desconocido');
  }

  state.rev += 1;
  pushLog(state, { ...op, at }, ref);
  return { ok: true, ref };
}

/** Mensajes en lenguaje humano para cada error (Nielsen #9: ayudar a recuperarse). */
export const ERROR_MESSAGES = {
  'titulo-invalido': 'Escribe un título (máximo 80 caracteres).',
  'nombre-invalido': 'Escribe un nombre (máximo 60 caracteres).',
  'texto-vacio': 'El fragmento está vacío. Escribe algo antes de publicar.',
  'archivo-invalido': 'No se pudo leer el archivo. Prueba con otra foto o grabación.',
  'ubicacion-invalida': 'La ubicación no es válida. Toca otro punto del mapa.',
  'ruta-corta': 'Una ruta necesita al menos 2 nodos. Toca otro nodo en el mapa.',
  'nodo-no-existe': 'Ese nodo ya no existe (quizá otra persona lo eliminó).',
  'fragmento-no-existe': 'Ese fragmento ya no existe (quizá otra persona lo eliminó).',
  'ruta-no-existe': 'Esa ruta ya no existe.',
  'historia-no-existe': 'La historia ya no existe.',
  'conflicto': 'Otra persona guardó cambios mientras editabas.',
  'almacenamiento-lleno': 'El almacenamiento del navegador está lleno. Usa fotos más pequeñas o audios más cortos.',
  'sin-autor': 'Elige tu nombre antes de contribuir.',
  'red': 'No se pudo conectar con el servidor.'
};
