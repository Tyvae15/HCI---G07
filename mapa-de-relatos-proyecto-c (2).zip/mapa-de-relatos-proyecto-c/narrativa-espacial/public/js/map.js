/**
 * map.js — EL MAPA COMO INTERFAZ PRINCIPAL (Leaflet + OpenStreetMap)
 * ----------------------------------------------------------------------------
 * Reto HCI: "interacción espacial legible". El mapa no es un adorno: aquí se
 * anclan nodos, se dibujan rutas y se recorre la historia.
 *
 * Codificación visual de los pines (color + símbolo, nunca solo color,
 * para personas con daltonismo — WCAG 1.4.1):
 *   Crear:    azul = nodo · naranja = "invita a continuar" · número = fragmentos
 *   Recorrer: gris "?" = por descubrir · verde "✓" = leído · número = orden en la ruta
 */
import { activeFragments, hasRead } from './model.js';
import { esc } from './ui.js';

export class MapView {
  /** ¿Cargó Leaflet? Si no (sin internet), la app usa la vista de lista. */
  static isAvailable() { return typeof window.L !== 'undefined'; }

  /**
   * @param {HTMLElement} el contenedor
   * @param {object} h manejadores: onNodeClick(id), onMapClick({lat,lng}), onNodeMoved(id,{lat,lng})
   */
  constructor(el, h) {
    this.h = h;
    this.map = L.map(el, { zoomControl: false, keyboard: true }).setView([-12.1492, -77.0222], 16);
    L.control.zoom({ position: 'topright', zoomInTitle: 'Acercar', zoomOutTitle: 'Alejar' }).addTo(this.map);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(this.map);

    // Capas separadas: así se redibuja cada cosa sin tocar lo demás.
    this.routeLayer = L.layerGroup().addTo(this.map);
    this.nodeLayer = L.layerGroup().addTo(this.map);
    this.draftLayer = L.layerGroup().addTo(this.map);
    this.meLayer = L.layerGroup().addTo(this.map);

    this.map.on('click', e => this.h.onMapClick?.({ lat: e.latlng.lat, lng: e.latlng.lng }));
  }

  /**
   * Dibuja nodos y rutas según el contexto actual.
   * ctx = {state, storyId, nodes, routes, role, userId, selectedId, tool, draftIds, walkRouteId}
   */
  render(ctx) {
    const { state, nodes, routes, role, userId, selectedId, tool, draftIds = [], walkRouteId } = ctx;
    this.nodeLayer.clearLayers();
    this.routeLayer.clearLayers();
    this.draftLayer.clearLayers();
    const byId = Object.fromEntries(nodes.map(n => [n.id, n]));
    const walkRoute = routes.find(r => r.id === walkRouteId);

    // --- Rutas (debajo de los pines) ---
    for (const r of routes) {
      const pts = r.nodeIds.map(id => byId[id]).filter(Boolean).map(n => [n.lat, n.lng]);
      if (pts.length < 2) continue;
      const faded = walkRoute && walkRoute.id !== r.id; // al recorrer, las otras rutas se atenúan
      L.polyline(pts, { color: r.color, weight: faded ? 3 : 6, opacity: faded ? 0.25 : 0.8, lineCap: 'round' })
        .bindTooltip(esc(r.name), { sticky: true })
        .addTo(this.routeLayer);
    }

    // --- Pines de nodos ---
    for (const n of nodes) {
      const read = hasRead(state, userId, n.id);
      let cls = 'pin';
      let label;
      if (role === 'crear') {
        cls += n.open ? ' pin--invite' : '';
        label = activeFragments(n).length;
      } else {
        cls += read ? ' pin--read' : ' pin--locked';
        const pos = walkRoute ? walkRoute.nodeIds.indexOf(n.id) : -1;
        label = pos >= 0 ? pos + 1 : (read ? '✓' : '?');
      }
      if (n.id === selectedId) cls += ' pin--selected';
      if (draftIds.includes(n.id)) cls += ' pin--draft';

      const status = role === 'crear'
        ? `${activeFragments(n).length} fragmentos${n.open ? ', invita a continuar' : ''}`
        : (read ? 'leído' : 'por descubrir');
      const marker = L.marker([n.lat, n.lng], {
        icon: L.divIcon({
          className: 'pin-wrap',
          html: `<div class="${cls}"><span>${esc(label)}</span></div>`,
          iconSize: [40, 40], iconAnchor: [20, 40]
        }),
        // title/alt = texto accesible del pin para lectores de pantalla y teclado.
        title: `${n.title} (${status})`,
        alt: `${n.title}, ${status}`,
        keyboard: true,
        riseOnHover: true,
        // Solo en Crear, con el nodo seleccionado y sin herramienta activa, se puede arrastrar.
        draggable: role === 'crear' && n.id === selectedId && tool === 'idle'
      });
      marker.on('click', () => this.h.onNodeClick?.(n.id));
      marker.on('dragend', e => {
        const p = e.target.getLatLng();
        this.h.onNodeMoved?.(n.id, { lat: p.lat, lng: p.lng });
      });
      marker.bindTooltip(esc(n.title), { direction: 'top', offset: [0, -38], className: 'pin-label' });
      marker.addTo(this.nodeLayer);
    }

    // --- Ruta en borrador (línea punteada mientras se dibuja) ---
    const draftPts = draftIds.map(id => byId[id]).filter(Boolean).map(n => [n.lat, n.lng]);
    if (draftPts.length >= 2) {
      L.polyline(draftPts, { color: '#1d2433', weight: 4, dashArray: '8 8' }).addTo(this.draftLayer);
    }
  }

  /** Encuadra la historia: todos sus nodos, o el centro guardado si está vacía. */
  fitStory(nodes, center) {
    if (nodes.length >= 2) {
      this.map.fitBounds(L.latLngBounds(nodes.map(n => [n.lat, n.lng])), { padding: [60, 60], maxZoom: 18 });
    } else if (nodes.length === 1) {
      this.map.setView([nodes[0].lat, nodes[0].lng], 17);
    } else if (center) {
      this.map.setView([center.lat, center.lng], center.zoom || 16);
    }
  }

  /** Lleva la vista a un nodo con animación suave. */
  focusNode(node) {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const zoom = Math.max(this.map.getZoom(), 17);
    if (reduce) this.map.setView([node.lat, node.lng], zoom);
    else this.map.flyTo([node.lat, node.lng], zoom, { duration: 0.6 });
  }

  /** Centro actual (para "dónde empieza" una historia nueva). */
  center() {
    const c = this.map.getCenter();
    return { lat: c.lat, lng: c.lng, zoom: this.map.getZoom() };
  }

  /** Dibuja el punto azul "estás aquí" y el círculo de precisión del GPS. */
  showMe(pos) {
    this.meLayer.clearLayers();
    if (!pos) return;
    L.circle([pos.lat, pos.lng], { radius: pos.accuracy || 20, color: '#2563eb', weight: 1, fillOpacity: 0.08 }).addTo(this.meLayer);
    L.marker([pos.lat, pos.lng], {
      icon: L.divIcon({ className: 'pin-wrap', html: '<div class="me-dot"></div>', iconSize: [18, 18], iconAnchor: [9, 9] }),
      title: 'Tu ubicación', keyboard: false, interactive: false
    }).addTo(this.meLayer);
  }

  /** Recalcula el tamaño (necesario si cambia el layout, p. ej. al plegar el panel). */
  refreshSize() { this.map.invalidateSize(); }
}
