/**
 * store.js — ALMACÉN DE DATOS DEL NAVEGADOR (sincronización y modo sin conexión)
 * ----------------------------------------------------------------------------
 * La interfaz nunca modifica datos directamente: llama a store.dispatch(op).
 *
 * Dos modos (se detectan solos al iniciar):
 *  • "server": la app se abrió desde `node server.mjs`. Los cambios se envían
 *    al servidor y cada 4 s se consultan los cambios de otras personas.
 *    Si se cae la señal, las ops se guardan en una "bandeja de salida" y se
 *    envían al volver la conexión (requisito: tolerancia a "sin señal").
 *  • "local": no hay servidor (p. ej. GitHub Pages). Todo se guarda en
 *    localStorage. Varias pestañas del mismo navegador se sincronizan entre sí,
 *    lo que permite simular varios autores en las pruebas.
 *
 * Eventos que emite (la UI los escucha):
 *  'change'   → el estado cambió  (detail: {remote:boolean, newLog:[]})
 *  'status'   → cambió el estado de conexión (detail: {mode, online, pending})
 *  'conflict' → una op enviada sin conexión chocó al sincronizar
 */
import { applyOp, emptyState, uid } from './model.js';
import { seedState } from './seed.js';

const LS_STATE = 'mr.state.v1';
const LS_OUTBOX = 'mr.outbox.v1';
const POLL_MS = 4000;

/** Lectura/escritura segura de localStorage (puede estar bloqueado o lleno). */
const safeLS = {
  get(key) { try { return JSON.parse(localStorage.getItem(key)); } catch { return null; } },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch { return false; }
  }
};

export class Store extends EventTarget {
  constructor() {
    super();
    this.state = emptyState();
    this.mode = 'local';
    this.online = navigator.onLine;
    this.outbox = safeLS.get(LS_OUTBOX) || []; // ops pendientes de enviar
    this.userId = null;
    this.ready = false; // hasta terminar init() no se anuncian cambios "remotos" (evita avisos masivos al abrir)
  }

  /** Detecta el modo, carga los datos y arranca la sincronización. */
  async init() {
    try {
      const r = await fetch('api/ping', { cache: 'no-store' });
      if (r.ok) this.mode = 'server';
    } catch { /* sin servidor → modo local */ }

    if (this.mode === 'server') {
      // Mientras llega el estado del servidor, se muestra la última copia guardada.
      this.state = safeLS.get(LS_STATE) || this.state;
      await this.pull(true);
      await this.flush();
      this._timer = setInterval(() => this.pull(), POLL_MS);
    } else {
      this.state = safeLS.get(LS_STATE) || seedState();
      safeLS.set(LS_STATE, this.state);
      // Otra pestaña guardó → recargar (simula colaboración entre "dispositivos").
      window.addEventListener('storage', e => {
        if (e.key !== LS_STATE || !e.newValue) return;
        const prevRev = this.state.rev;
        try { this.state = JSON.parse(e.newValue); } catch { return; }
        this._emitChange(true, prevRev);
      });
    }

    this.ready = true;
    window.addEventListener('online', () => { this.online = true; this._emitStatus(); this.flush(); });
    window.addEventListener('offline', () => { this.online = false; this._emitStatus(); });
    this._emitStatus();
  }

  /**
   * Envía una operación. Devuelve {ok, error?, conflict?, pending?}.
   * La UI muestra el resultado al instante (retroalimentación inmediata).
   */
  async dispatch(type, payload) {
    if (!this.userId && type !== 'user.upsert') return { ok: false, error: 'sin-autor' };
    const op = { id: uid('op'), type, by: this.userId || payload?.id, at: new Date().toISOString(), payload };

    if (this.mode === 'local') {
      const before = JSON.stringify(this.state);
      const res = applyOp(this.state, op);
      if (!res.ok) return res;
      if (!safeLS.set(LS_STATE, this.state)) {
        // No cupo en localStorage (fotos/audios pesados): se revierte el cambio.
        this.state = JSON.parse(before);
        return { ok: false, error: 'almacenamiento-lleno' };
      }
      this._emitChange(false);
      return res;
    }

    // Modo servidor: primero se valida localmente (respuesta inmediata) …
    const probe = applyOp(structuredClone(this.state), op);
    if (!probe.ok) return probe;

    // … y luego se envía. Si no hay red, va a la bandeja de salida.
    try {
      const data = await this._post([op]);
      const result = data.results[0];
      this._replaceState(data.state, false);
      return result;
    } catch {
      this.outbox.push(op);
      safeLS.set(LS_OUTBOX, this.outbox);
      applyOp(this.state, op);          // se ve el cambio aunque esté pendiente
      safeLS.set(LS_STATE, this.state);
      this.online = false;
      this._emitStatus();
      this._emitChange(false);
      return { ...probe, pending: true };
    }
  }

  /** Trae el estado del servidor si cambió (polling cada 4 s). */
  async pull(force = false) {
    if (this.mode !== 'server') return;
    try {
      const since = force ? '' : `?since=${this.state.rev}`;
      const r = await fetch(`api/state${since}`, { cache: 'no-store' });
      if (!r.ok) throw new Error('http');
      const data = await r.json();
      if (!this.online) { this.online = true; this._emitStatus(); this.flush(); }
      if (data.unchanged) return;
      // Si hay ops pendientes, se vuelven a aplicar sobre el estado nuevo para no "perderlas" de la vista.
      const next = data.state;
      for (const op of this.outbox) applyOp(next, op);
      this._replaceState(next, true);
    } catch {
      if (this.online) { this.online = false; this._emitStatus(); }
    }
  }

  /** Envía la bandeja de salida. Conflictos → evento 'conflict' para que la persona decida. */
  async flush() {
    if (this.mode !== 'server' || !this.outbox.length) return;
    const ops = [...this.outbox];
    try {
      const data = await this._post(ops);
      this.outbox = [];
      safeLS.set(LS_OUTBOX, this.outbox);
      this._replaceState(data.state, true);
      data.results.filter(r => !r.ok && r.conflict).forEach(r =>
        this.dispatchEvent(new CustomEvent('conflict', { detail: r })));
      this._emitStatus();
    } catch { /* sigue sin red; se reintenta luego */ }
  }

  /** Restablece la demo (borra todo y vuelve a cargar los datos de ejemplo). */
  async reset() {
    if (this.mode === 'server') {
      const r = await fetch('api/reset', { method: 'POST' });
      const data = await r.json();
      this.outbox = [];
      safeLS.set(LS_OUTBOX, []);
      this._replaceState(data.state, false);
    } else {
      this.state = seedState();
      safeLS.set(LS_STATE, this.state);
      this._emitChange(false);
    }
  }

  /** Importa un JSON exportado (solo modo local, para no pisar el servidor compartido). */
  importState(obj) {
    if (!obj || typeof obj !== 'object' || !obj.nodes || !obj.stories) throw new Error('Archivo no válido');
    this.state = obj;
    safeLS.set(LS_STATE, this.state);
    this._emitChange(false);
  }

  // ------------------------------------------------------------- internos
  async _post(ops) {
    const r = await fetch('api/ops', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ops })
    });
    if (!r.ok) throw new Error('http ' + r.status);
    return r.json();
  }

  _replaceState(next, remote) {
    const prevRev = this.state.rev;
    this.state = next;
    safeLS.set(LS_STATE, next);
    this._emitChange(remote, prevRev);
  }

  /** Avisa a la UI. Incluye las entradas nuevas del registro hechas por OTRAS personas. */
  _emitChange(remote, prevRev = this.state.rev) {
    const newLog = remote && this.ready
      ? this.state.log.filter((e, i, arr) => i >= arr.length - (this.state.rev - prevRev) && e.by !== this.userId)
      : [];
    this.dispatchEvent(new CustomEvent('change', { detail: { remote, newLog } }));
  }

  _emitStatus() {
    this.dispatchEvent(new CustomEvent('status', {
      detail: { mode: this.mode, online: this.online, pending: this.outbox.length }
    }));
  }
}
