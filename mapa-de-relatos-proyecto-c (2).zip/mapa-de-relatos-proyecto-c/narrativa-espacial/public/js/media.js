/**
 * media.js — FOTOS Y AUDIO
 * ----------------------------------------------------------------------------
 * • Las fotos se reducen a máx. 1280 px y se comprimen en JPEG antes de
 *   guardarse (cargan rápido con datos móviles y caben en el almacenamiento).
 * • El audio se graba con el micrófono (MediaRecorder) hasta 90 segundos.
 * Ambos se guardan como "data URL" (texto base64) dentro del fragmento.
 */

const MAX_SIDE = 1280;
export const MAX_AUDIO_SECONDS = 90;

/** Convierte un archivo de imagen en un data URL JPEG comprimido. */
export function compressImage(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith('image/')) { reject(new Error('No es una imagen')); return; }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, MAX_SIDE / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/jpeg', 0.72));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('No se pudo leer la imagen')); };
    img.src = url;
  });
}

/** Lee un Blob como data URL. */
function blobToDataURL(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

/**
 * Grabador de audio sencillo.
 *   const rec = new AudioRecorder(onTick);
 *   await rec.start();  …  const dataUrl = await rec.stop();
 * onTick(segundos) se llama cada segundo para mostrar el cronómetro.
 */
export class AudioRecorder {
  constructor(onTick) {
    this.onTick = onTick;
    this.chunks = [];
    this.seconds = 0;
  }

  static isSupported() {
    return Boolean(navigator.mediaDevices?.getUserMedia && window.MediaRecorder);
  }

  async start() {
    // Pide permiso de micrófono. Si la persona lo niega, se lanza un error que la UI explica.
    this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.recorder = new MediaRecorder(this.stream);
    this.chunks = [];
    this.recorder.ondataavailable = e => e.data.size && this.chunks.push(e.data);
    this.recorder.start();
    this.seconds = 0;
    this.timer = setInterval(() => {
      this.seconds += 1;
      this.onTick?.(this.seconds);
      if (this.seconds >= MAX_AUDIO_SECONDS) this.stop(); // límite para no llenar el almacenamiento
    }, 1000);
  }

  stop() {
    if (this._stopping) return this._stopping;
    clearInterval(this.timer);
    this._stopping = new Promise(resolve => {
      if (!this.recorder || this.recorder.state === 'inactive') { resolve(null); return; }
      this.recorder.onstop = async () => {
        this.stream.getTracks().forEach(t => t.stop()); // apaga el micrófono (indicador del SO)
        const blob = new Blob(this.chunks, { type: this.recorder.mimeType || 'audio/webm' });
        resolve(await blobToDataURL(blob));
      };
      this.recorder.stop();
    });
    return this._stopping;
  }

  /** Cancela sin guardar (por ejemplo, si se cierra el formulario). */
  cancel() {
    clearInterval(this.timer);
    try { this.recorder?.stop(); } catch { /* ya detenido */ }
    this.stream?.getTracks().forEach(t => t.stop());
  }
}
