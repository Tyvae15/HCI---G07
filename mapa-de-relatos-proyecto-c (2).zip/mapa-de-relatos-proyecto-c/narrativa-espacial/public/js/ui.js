/**
 * ui.js — UTILIDADES DE INTERFAZ REUTILIZABLES
 * ----------------------------------------------------------------------------
 * Funciones pequeñas que usan todos los módulos: escapar texto, avisos
 * (toasts), diálogos accesibles, avatares y fechas relativas.
 */

/** Evita inyección de HTML: TODO texto escrito por usuarios pasa por aquí. */
export function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** Atajo de document.querySelector. */
export const $ = (sel, root = document) => root.querySelector(sel);

/** Avatar circular con la inicial y el color del autor (atribución visual). */
export function avatar(user, small = false) {
  const name = user?.name || '?';
  return `<span class="avatar${small ? ' avatar--sm' : ''}" style="background:${esc(user?.color || '#6b7280')}" aria-hidden="true">${esc(name[0].toUpperCase())}</span>`;
}

/** "hace 5 min", "hace 2 h"… (más fácil de leer que una fecha completa). */
const rtf = new Intl.RelativeTimeFormat('es', { numeric: 'auto' });
export function timeAgo(iso) {
  const s = (new Date(iso).getTime() - Date.now()) / 1000;
  const steps = [['year', 31536000], ['month', 2592000], ['day', 86400], ['hour', 3600], ['minute', 60]];
  for (const [unit, secs] of steps) if (Math.abs(s) >= secs) return rtf.format(Math.round(s / secs), unit);
  return 'justo ahora';
}

/**
 * Aviso breve no bloqueante. Puede incluir una acción (p. ej. "Deshacer").
 * type: 'ok' | 'error' | 'info'
 */
export function toast(message, { type = 'info', action = null, timeout = 4500 } = {}) {
  const box = document.getElementById('toasts');
  const t = document.createElement('div');
  t.className = `toast toast--${type}`;
  t.setAttribute('role', type === 'error' ? 'alert' : 'status');
  t.innerHTML = `<span>${esc(message)}</span>`;
  if (action) {
    const b = document.createElement('button');
    b.textContent = action.label;
    b.addEventListener('click', () => { action.fn(); t.remove(); });
    t.appendChild(b);
  }
  box.appendChild(t);
  // Los avisos con acción duran más para que dé tiempo de reaccionar.
  setTimeout(() => t.remove(), action ? Math.max(timeout, 7000) : timeout);
  // Máximo 3 avisos a la vez (no saturar la memoria de trabajo).
  while (box.children.length > 3) box.firstChild.remove();
}

/**
 * Abre el diálogo modal con el HTML dado. <dialog> nativo:
 *  - atrapa el foco dentro del diálogo, Esc lo cierra (accesible por defecto).
 * `onMount(root, close)` permite conectar eventos. Devuelve una promesa que se
 * resuelve con el valor pasado a close(valor).
 */
export function openDialog(html, onMount) {
  const dlg = document.getElementById('dialog');
  const content = document.getElementById('dialog-content');
  if (dlg.open) dlg.close();
  content.innerHTML = `<div class="dialog__inner">${html}</div>`;
  const opener = document.activeElement; // para devolver el foco al cerrar
  return new Promise(resolve => {
    let result = null;
    const close = value => { result = value ?? null; dlg.close(); };
    const onClose = () => {
      dlg.removeEventListener('close', onClose);
      content.dispatchEvent(new Event('dialog-closed')); // permite limpiar (p. ej. apagar cámara)
      if (opener && opener.focus && document.contains(opener)) opener.focus();
      resolve(result);
    };
    dlg.addEventListener('close', onClose);
    content.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', () => close(null)));
    onMount?.(content, close);
    dlg.showModal();
    // Enfoca el primer campo útil (o el primer botón).
    (content.querySelector('[autofocus]') || content.querySelector('input,textarea,select,button'))?.focus();
  });
}

/** Diálogo de confirmación (reemplaza a window.confirm, que bloquea y no se puede estilizar). */
export function confirmDialog({ title, body, confirm = 'Confirmar', danger = false }) {
  return openDialog(`
    <h2 id="dialog-title">${esc(title)}</h2>
    <p>${esc(body)}</p>
    <div class="dialog__actions">
      <button class="btn btn--ghost" data-close>Cancelar</button>
      <button class="btn ${danger ? 'btn--danger' : ''}" id="dlg-ok">${esc(confirm)}</button>
    </div>`, (root, close) => root.querySelector('#dlg-ok').addEventListener('click', () => close(true)));
}

/** Marca un campo como inválido con mensaje accesible (aria-invalid + texto). */
export function setFieldError(input, message) {
  const err = input.closest('.field')?.querySelector('.error');
  input.setAttribute('aria-invalid', message ? 'true' : 'false');
  if (err) err.textContent = message || '';
  if (message) input.focus();
}

/** Descarga un texto como archivo (exportar JSON/CSV). */
export function downloadText(filename, text, mime = 'application/json') {
  const blob = new Blob([text], { type: mime });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}

/** Emite un evento para el registro automático de la prueba de usabilidad. */
export function track(kind, detail = {}) {
  window.dispatchEvent(new CustomEvent('mr:track', { detail: { kind, ...detail, at: Date.now() } }));
}
