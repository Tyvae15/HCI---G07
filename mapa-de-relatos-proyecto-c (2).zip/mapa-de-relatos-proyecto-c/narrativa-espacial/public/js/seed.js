/**
 * seed.js — DATOS DE DEMOSTRACIÓN
 * ----------------------------------------------------------------------------
 * Crea una historia de ejemplo en Barranco (Lima) para que el prototipo no
 * arranque vacío en las pruebas con usuarios. Se construye con las mismas
 * operaciones que usa la app (applyOp), así los datos siempre son válidos.
 */
import { emptyState, applyOp } from './model.js';

export function seedState() {
  const s = emptyState();
  const t0 = Date.now() - 1000 * 60 * 60 * 26; // hace ~1 día
  let k = 0;
  // Pequeño ayudante: aplica una op con fecha creciente y falla en voz alta si algo está mal.
  const op = (type, by, payload) => {
    const r = applyOp(s, { id: `seed_${k}`, type, by, at: new Date(t0 + k++ * 60000 * 7).toISOString(), payload });
    if (!r.ok) throw new Error(`Seed inválido en ${type}: ${r.error}`);
  };

  op('user.upsert', 'u_ana', { id: 'u_ana', name: 'Ana', color: '#b45309' });
  op('user.upsert', 'u_luis', { id: 'u_luis', name: 'Luis', color: '#7c3aed' });

  op('story.create', 'u_ana', {
    id: 's_barranco',
    title: 'Ecos de Barranco',
    description: 'Una carta perdida recorre el barrio. Cada lugar guarda una pista. ¿Quién la escribió?',
    center: { lat: -12.1492, lng: -77.0222, zoom: 17 }
  });
  op('story.create', 'u_luis', {
    id: 's_campus',
    title: 'Leyendas del campus',
    description: 'Historia en blanco para practicar: ancla el primer nodo en el campus.',
    center: { lat: -12.0847, lng: -76.9714, zoom: 17 }
  });

  op('node.create', 'u_ana', { id: 'n_plaza', storyId: 's_barranco', code: 'PLZ3', lat: -12.14870, lng: -77.02065, title: 'La carta en la banca', place: 'Plaza de Barranco', open: false });
  op('node.create', 'u_ana', { id: 'n_puente', storyId: 's_barranco', code: 'BRC2', lat: -12.14905, lng: -77.02212, title: 'Contener la respiración', place: 'Puente de los Suspiros', open: false });
  op('node.create', 'u_luis', { id: 'n_bajada', storyId: 's_barranco', code: 'BJD4', lat: -12.14975, lng: -77.02320, title: 'Pasos hacia el mar', place: 'Bajada de Baños', open: true });
  op('node.create', 'u_luis', { id: 'n_malecon', storyId: 's_barranco', code: 'MLC5', lat: -12.15030, lng: -77.02440, title: 'El horizonte responde', place: 'Mirador del malecón', open: true });

  op('fragment.add', 'u_ana', { nodeId: 'n_plaza', fragment: { id: 'f1', kind: 'text', text: 'Bajo la tercera banca, frente a la glorieta, Martina encontró un sobre amarillento. Solo decía: "Crúzalo sin respirar y sabrás quién soy".' } });
  op('fragment.add', 'u_luis', { nodeId: 'n_plaza', fragment: { id: 'f2', kind: 'text', text: 'El vendedor de raspadillas juró haber visto a un hombre de sombrero dejarlo ahí cada domingo durante cuarenta años.' } });
  op('fragment.add', 'u_ana', { nodeId: 'n_puente', fragment: { id: 'f3', kind: 'text', text: 'Martina cruzó el puente conteniendo el aliento. A mitad de camino, entre las tablas, vio grabadas dos iniciales: R. y M.' } });
  op('fragment.add', 'u_luis', { nodeId: 'n_bajada', fragment: { id: 'f4', kind: 'text', text: 'Al bajar hacia el mar, el ruido de las olas tapaba todo. Alguien la seguía, o eso creyó.' } });
  op('fragment.edit', 'u_ana', { nodeId: 'n_bajada', fragmentId: 'f4', baseVersion: 1, text: 'Al bajar hacia el mar, el ruido de las olas tapaba todo. Alguien la seguía, o eso creyó. Las iniciales R. y M. aparecían otra vez en una pared húmeda.' });

  op('route.create', 'u_ana', { id: 'r_carta', storyId: 's_barranco', name: 'La ruta de la carta', nodeIds: ['n_plaza', 'n_puente', 'n_bajada', 'n_malecon'], color: '#0b5cad' });

  // Luis ya leyó los dos primeros nodos (para que se vea "Leído por…").
  op('read.mark', 'u_luis', { nodeId: 'n_plaza', via: 'qr' });
  op('read.mark', 'u_luis', { nodeId: 'n_puente', via: 'gps' });
  return s;
}
