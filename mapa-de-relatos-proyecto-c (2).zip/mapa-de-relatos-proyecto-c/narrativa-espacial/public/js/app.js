/**
 * app.js — CONTROLADOR PRINCIPAL DE LA INTERFAZ
 * ----------------------------------------------------------------------------
 * Une todas las piezas:
 *   store.js (datos)  ←→  app.js (decisiones de interfaz)  ←→  map.js / qr.js / media.js
 *
 * Flujo general:
 *   1. El usuario hace algo (clic, tecla, escaneo, GPS).
 *   2. app.js llama a store.dispatch('tipo.de.op', datos).
 *   3. El store aplica la op (local o en el servidor) y emite 'change'.
 *   4. app.js vuelve a dibujar (render) mapa, panel y barras.
 *
 * Estado de interfaz (NO compartido con otros usuarios): rol actual, nodo
 * seleccionado, herramienta activa, ruta en borrador, recorrido en curso, etc.
 */
import { Store } from './store.js';
import { MapView } from './map.js';
import * as M from './model.js';
import { esc, $, avatar, timeAgo, toast, openDialog, confirmDialog, setFieldError, downloadText, track } from './ui.js';
import { openScanner, showNodeQr, printQrSheet } from './qr.js';
import { compressImage, AudioRecorder, MAX_AUDIO_SECONDS } from './media.js';
import { openTestPanel } from './testmode.js';

// ============================================================================
// 1. ESTADO
// ============================================================================
const store = new Store();
let mapView = null;

/** Radio (m) para desbloquear un nodo por cercanía GPS. */
const UNLOCK_RADIUS_M = 40;

/** Preferencias de este dispositivo (quién soy, qué historia y rol tenía abiertos). */
const PREFS_KEY = 'mr.prefs.v1';
const prefs = (() => { try { return JSON.parse(localStorage.getItem(PREFS_KEY)) || {}; } catch { return {}; } })();
const savePrefs = () => { try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); } catch { /* sin almacenamiento */ } };

/** Estado de la interfaz. */
const ui = {
  role: prefs.role || 'crear',   // 'crear' | 'recorrer'
  storyId: prefs.storyId || null,
  selectedId: null,              // nodo abierto en el panel
  tool: 'idle',                  // 'idle' | 'anchor' | 'route'
  draft: [],                     // ids de nodos de la ruta en borrador
  walk: null,                    // {routeId, index} recorrido en curso
  me: null,                      // última posición GPS {lat,lng,accuracy}
  watchId: null,                 // id de geolocation.watchPosition
  composer: null,                // {nodeId, kind:'text'|'photo'|'audio', media, rec, recording}
  editing: null,                 // {nodeId, fragmentId, baseVersion, text}
  justFinished: null             // id de ruta recién completada (para invitar a continuar)
};

// Atajos de lectura del estado
const S = () => store.state;
const story = () => S().stories[ui.storyId];
const nodes = () => M.activeNodes(S(), ui.storyId);
const routes = () => M.activeRoutes(S(), ui.storyId);
const me = () => S().users[store.userId];
const userOf = id => S().users[id] || { name: 'Alguien', color: '#6b7280' };
const selectedNode = () => {
  const n = S().nodes[ui.selectedId];
  return n && !n.deleted ? n : null;
};

/**
 * Ejecuta una operación y, si falla, explica el error en lenguaje humano.
 * Devuelve el resultado para que quien llama decida qué hacer (p. ej. conflictos).
 */
async function run(type, payload, { quiet = false } = {}) {
  const res = await store.dispatch(type, payload);
  if (!res.ok && !quiet && res.error !== 'conflicto') {
    toast(M.ERROR_MESSAGES[res.error] || `No se pudo completar la acción (${res.error}).`, { type: 'error' });
    track('error', { what: res.error });
  }
  if (res.pending) toast('Sin conexión: el cambio se guardó en tu dispositivo y se enviará al volver la señal.', { type: 'info' });
  return res;
}

// ============================================================================
// 2. DIBUJADO (render)
// ============================================================================
function render({ remote = false } = {}) {
  if (!story()) ui.storyId = Object.keys(S().stories)[0] || null;
  if (ui.selectedId && !selectedNode()) ui.selectedId = null;
  renderTopbar();
  renderMap();
  // Si la persona está escribiendo y llega un cambio remoto, NO se redibuja el
  // panel (perdería lo que escribe). El mapa sí se actualiza.
  if (!(remote && (ui.composer || ui.editing))) renderPanel();
  renderBars();
}

function renderTopbar() {
  document.body.dataset.role = ui.role;
  $('#story-title').textContent = story()?.title || 'Sin historia';
  $('#role-crear').setAttribute('aria-pressed', String(ui.role === 'crear'));
  $('#role-recorrer').setAttribute('aria-pressed', String(ui.role === 'recorrer'));
  $('#tools-crear').hidden = ui.role !== 'crear';
  $('#tools-recorrer').hidden = ui.role !== 'recorrer';
  $('#tool-anchor').setAttribute('aria-pressed', String(ui.tool === 'anchor'));
  $('#tool-route').setAttribute('aria-pressed', String(ui.tool === 'route'));
  $('#tool-locate').setAttribute('aria-pressed', String(ui.watchId !== null));
  document.body.classList.toggle('tool-anchor', ui.tool === 'anchor');
  const u = me();
  $('#user-avatar').outerHTML = u ? avatar(u).replace('class="avatar"', 'id="user-avatar" class="avatar"') : '<span id="user-avatar" class="avatar">?</span>';
  $('#user-name').textContent = u?.name || 'Elegir nombre';
}

function renderMap() {
  if (!mapView) return;
  mapView.render({
    state: S(), nodes: nodes(), routes: routes(), role: ui.role, userId: store.userId,
    selectedId: ui.selectedId, tool: ui.tool, draftIds: ui.draft,
    walkRouteId: ui.role === 'recorrer' ? ui.walk?.routeId : null
  });
}

/** Barras contextuales: pista superior, ruta en borrador y recorrido. */
function renderBars() {
  // Pista: le dice a la persona qué hacer ahora (reduce la carga de memoria).
  let hint = '';
  if (ui.tool === 'anchor') hint = 'Toca en el mapa el lugar donde ocurre la escena · Esc para cancelar';
  else if (ui.tool === 'route') hint = ui.draft.length ? `Ruta con ${ui.draft.length} nodo(s) · toca el siguiente pin o guarda` : 'Toca los pines en el orden en que se leerá la historia';
  else if (ui.role === 'recorrer' && !ui.walk && !ui.selectedId) hint = 'Elige una ruta en el panel o escanea el QR de un lugar para empezar';
  else if (ui.role === 'crear' && !nodes().length) hint = 'Historia vacía: usa “Anclar nodo” para crear el primer lugar';
  $('#hint').textContent = hint;

  // Barra de ruta en borrador
  $('#route-bar').hidden = ui.tool !== 'route';
  $('#route-bar-text').textContent = `Ruta: ${ui.draft.length} nodo(s)`;
  $('#route-save').disabled = ui.draft.length < 2;
  $('#route-undo').disabled = !ui.draft.length;

  // Barra de recorrido
  const walkRoute = ui.walk && S().routes[ui.walk.routeId];
  const showWalk = ui.role === 'recorrer' && walkRoute && !walkRoute.deleted;
  $('#walk-bar').hidden = !showWalk;
  if (showWalk) {
    const p = M.routeProgress(S(), store.userId, walkRoute);
    $('#walk-name').textContent = walkRoute.name;
    $('#walk-step').textContent = `Parada ${ui.walk.index + 1} de ${walkRoute.nodeIds.length} · ${p.done} leída(s)`;
    $('#walk-progress').style.width = `${p.pct}%`;
    $('#walk-prev').disabled = ui.walk.index === 0;
    $('#walk-next').textContent = ui.walk.index >= walkRoute.nodeIds.length - 1 ? 'Terminar ✓' : 'Siguiente ▶';
  }
}

// ----------------------------------------------------------- Panel lateral
function renderPanel() {
  const body = $('#panel-body');
  const node = selectedNode();
  body.innerHTML = node ? nodeView(node) : storyView();
  // Restaura el borrador del compositor (si estaba abierto).
  const ta = body.querySelector('#composer-text');
  if (ta && ui.composer) ta.value = loadDraft(ui.composer.nodeId);
  updateDistance();
}

/** Vista general de la historia: rutas, dónde contribuir, lugares y actividad. */
function storyView() {
  const st = story();
  if (!st) return '<p>No hay historias. Crea una desde el botón “Historia”.</p>';
  const ns = nodes();
  const rs = routes();
  const authors = new Set([...ns.map(n => n.createdBy), ...ns.flatMap(n => M.activeFragments(n).map(f => f.authorId))]);
  const points = M.contributionPoints(S(), ui.storyId).slice(0, 4);

  const routeItems = rs.map(r => {
    const p = M.routeProgress(S(), store.userId, r);
    return `<li class="list-item" style="cursor:default">
      <span class="list-item__main"><strong>${esc(r.name)}</strong>
        <span>${r.nodeIds.length} paradas · ${p.done}/${p.total} leídas · por ${esc(userOf(r.createdBy).name)}</span>
        <div class="progress" style="margin-top:4px" aria-hidden="true"><div class="progress__fill" style="width:${p.pct}%"></div></div>
      </span>
      <button class="btn btn--small" data-act="walk" data-id="${r.id}">${p.done && p.done < p.total ? 'Continuar' : 'Recorrer'}</button>
      ${ui.role === 'crear' ? `<button class="icon-btn" data-act="route-del" data-id="${r.id}" title="Eliminar ruta"><span aria-hidden="true">🗑</span><span class="sr-only">Eliminar ruta ${esc(r.name)}</span></button>` : ''}
    </li>`;
  }).join('');

  const activity = S().log.filter(e => e.storyId === ui.storyId && e.type !== 'user.upsert').slice(-6).reverse();

  return `
    <h2>${esc(st.title)}</h2>
    <p class="muted">${esc(st.description)}</p>
    <div class="stats">
      <div class="stat"><strong>${ns.length}</strong><span>lugares</span></div>
      <div class="stat"><strong>${rs.length}</strong><span>rutas</span></div>
      <div class="stat"><strong>${authors.size}</strong><span>autores</span></div>
    </div>

    ${!ns.length ? `
      <div class="invite-box">
        <strong>Esta historia aún no tiene lugares.</strong>
        <p class="small">Toca “Anclar nodo” y luego el punto del mapa donde empieza la historia.</p>
        <button class="btn" data-act="start-anchor">📍 Anclar el primer nodo</button>
      </div>` : ''}

    <h3>Rutas</h3>
    ${rs.length ? `<ul class="list">${routeItems}</ul>` : `<p class="muted small">Aún no hay rutas. ${ui.role === 'crear' ? 'Usa “Dibujar ruta” para unir lugares en orden.' : 'Cambia a “Crear” para dibujar una.'}</p>`}

    ${points.length ? `
      <h3>Dónde puedes contribuir</h3>
      <ul class="list">${points.map(({ node, reasons }) => `
        <li><button class="list-item" data-act="select" data-id="${node.id}">
          <span aria-hidden="true">✍️</span>
          <span class="list-item__main"><strong>${esc(node.title)}</strong><span>${esc(reasons.join(' · '))}</span></span>
        </button></li>`).join('')}</ul>` : ''}

    <h3>Lugares</h3>
    ${nodeList(ns)}

    <h3>Actividad reciente</h3>
    ${activity.length ? `<ul class="list small">${activity.map(e => `<li class="row">${avatar(userOf(e.by), true)} <span>${describeLog(e)} · <span class="muted">${timeAgo(e.at)}</span></span></li>`).join('')}</ul>` : '<p class="muted small">Sin actividad todavía.</p>'}
  `;
}

/** Lista de nodos (alternativa accesible al mapa y vista de respaldo sin internet). */
function nodeList(ns) {
  if (!ns.length) return '<p class="muted small">Sin lugares.</p>';
  return `<ul class="list">${ns.map(n => {
    const read = M.hasRead(S(), store.userId, n.id);
    const badge = ui.role === 'crear'
      ? (n.open ? '<span class="badge badge--invite">Invita a continuar</span>' : `<span class="badge">${M.activeFragments(n).length} frag.</span>`)
      : (read ? '<span class="badge badge--ok">✓ Leído</span>' : '<span class="badge badge--locked">🔒 Por descubrir</span>');
    return `<li><button class="list-item" data-act="select" data-id="${n.id}">
      <span class="list-item__main"><strong>${esc(n.title)}</strong><span>${esc(n.place || 'Sin nombre de lugar')}</span></span>${badge}
    </button></li>`;
  }).join('')}</ul>`;
}

/** Texto de una entrada de actividad: "Ana agregó un fragmento en «Puente»". */
function describeLog(e) {
  const who = `<strong>${esc(userOf(e.by).name)}</strong>`;
  const node = e.nodeId && S().nodes[e.nodeId];
  const route = e.routeId && S().routes[e.routeId];
  const target = node ? `«${esc(node.title)}»` : route ? `«${esc(route.name)}»` : '';
  const verbs = {
    'story.create': 'creó la historia', 'node.create': 'ancló el lugar', 'node.update': 'editó',
    'node.delete': 'eliminó', 'node.restore': 'restauró', 'fragment.add': 'agregó un fragmento en',
    'fragment.edit': 'editó un fragmento en', 'fragment.delete': 'eliminó un fragmento en',
    'fragment.restore': 'restauró un fragmento en', 'route.create': 'creó la ruta', 'route.update': 'editó la ruta',
    'route.delete': 'eliminó la ruta', 'route.restore': 'restauró la ruta', 'read.mark': 'leyó'
  };
  return `${who} ${verbs[e.type] || e.type} ${target}`;
}

/** Vista de un nodo: fragmentos, atribución, lectores, bloqueo y acciones. */
function nodeView(n) {
  const read = M.hasRead(S(), store.userId, n.id);
  const locked = ui.role === 'recorrer' && !read;
  const readers = M.readersOf(S(), n.id);
  const through = M.routesThrough(S(), n.id);
  const frags = M.activeFragments(n);
  const walkRoute = ui.walk && S().routes[ui.walk.routeId];
  const finished = ui.justFinished && walkRoute?.nodeIds.at(-1) === n.id;

  return `
    <button class="link-btn back-btn" data-act="back">← Volver a la historia</button>
    <h2>${esc(n.title)}</h2>
    <p class="row small"><span>📍 ${esc(n.place || 'Lugar sin nombre')}</span> <span class="code-chip" title="Código del lugar">${esc(n.code)}</span></p>
    <p class="small muted">Creado por ${esc(userOf(n.createdBy).name)} · ${timeAgo(n.createdAt)}</p>
    ${through.length ? `<p class="row small">${through.map(t => `<span class="badge">${esc(t.route.name)} · parada ${t.position}/${t.route.nodeIds.length}</span>`).join('')}</p>` : ''}
    <p class="small" id="readers">👁 ${readers.length ? `Leído por ${readers.slice(0, 3).map(r => esc(r.user.name)).join(', ')}${readers.length > 3 ? ` y ${readers.length - 3} más` : ''}` : 'Nadie lo ha leído aún'}</p>

    ${finished ? `
      <div class="success-box">
        <strong>🎉 ¡Completaste “${esc(walkRoute.name)}”!</strong>
        <p class="small">La historia puede seguir. ¿Qué pasa después de este lugar?</p>
        <button class="btn" data-act="compose" data-kind="text">✍️ Continuar la historia aquí</button>
      </div>` : ''}

    ${locked ? `
      <div class="locked-box">
        <div class="locked-box__icon" aria-hidden="true">🔒</div>
        <p><strong>Este fragmento se revela en el lugar.</strong></p>
        <p class="small muted" id="dist-text">${ui.me ? '' : 'Activa “Mi ubicación” para desbloquearlo al llegar, o escanea su QR.'}</p>
        <div class="row" style="justify-content:center">
          <button class="btn" data-act="scan">📷 Escanear QR</button>
          <button class="btn btn--ghost" data-act="code">⌨️ Ingresar código</button>
        </div>
        <button class="link-btn" data-act="read-remote">Leer sin estar en el lugar</button>
      </div>` : `
      <h3>Fragmentos (${frags.length})</h3>
      ${frags.length ? frags.map(f => fragmentCard(n, f)).join('') : '<p class="muted small">Todavía no hay fragmentos en este lugar.</p>'}
      ${ui.composer?.nodeId === n.id ? composerHtml() : `
        ${ui.role === 'recorrer'
          ? `<div class="invite-box"><strong>¿Qué pasa después?</strong>
               <p class="small">Puedes continuar la historia desde aquí sin dejar el recorrido.</p>
               <button class="btn" data-act="compose" data-kind="text">✍️ Continuar la historia aquí</button></div>`
          : `<button class="btn btn--block" data-act="compose" data-kind="text">＋ Agregar fragmento</button>`}`}
    `}

    ${ui.role === 'crear' ? `
      <h3>Acciones del lugar</h3>
      <div class="row">
        <button class="btn btn--ghost btn--small" data-act="node-edit">✏️ Editar</button>
        <button class="btn btn--ghost btn--small" data-act="node-qr">🔳 Ver QR</button>
        <button class="btn btn--ghost btn--small" data-act="node-open" aria-pressed="${n.open}">${n.open ? '✅ Invitando a continuar' : '🙋 Invitar a continuar'}</button>
        <button class="btn btn--ghost btn--small danger-text" data-act="node-del">🗑 Eliminar</button>
      </div>
      <p class="small muted">Para moverlo, arrastra el pin seleccionado en el mapa.</p>` : ''}
  `;
}

/** Tarjeta de un fragmento con autor, versión y acciones. */
function fragmentCard(n, f) {
  const author = userOf(f.authorId);
  const edited = f.version > 1 ? ` · v${f.version}, editado por ${esc(userOf(f.updatedBy).name)} ${timeAgo(f.updatedAt)}` : '';
  const editing = ui.editing?.fragmentId === f.id;
  let content = '';
  if (f.kind === 'photo') content = `<img src="${esc(f.media)}" alt="${esc(f.text || `Foto aportada por ${author.name}`)}" loading="lazy">`;
  if (f.kind === 'audio') content = `<audio controls preload="none" src="${esc(f.media)}" aria-label="Audio de ${esc(author.name)}"></audio>`;

  return `<article class="fragment" aria-label="Fragmento de ${esc(author.name)}">
    <div class="fragment__head">${avatar(author)}<div><strong>${esc(author.name)}</strong>
      <div class="fragment__meta">${timeAgo(f.createdAt)}${edited}</div></div></div>
    ${content}
    ${editing ? `
      <form id="edit-form" data-node="${n.id}" data-frag="${f.id}" novalidate>
        <div class="field"><label for="edit-text">${f.kind === 'text' ? 'Editar texto' : 'Editar descripción'}</label>
          <textarea id="edit-text" maxlength="4000">${esc(ui.editing.text)}</textarea><span class="error" role="alert"></span></div>
        <div class="row"><button type="button" class="btn btn--ghost btn--small" data-act="edit-cancel">Cancelar</button>
          <button type="submit" class="btn btn--small">Guardar cambios</button></div>
      </form>` : (f.text ? `<p class="fragment__text">${esc(f.text)}</p>` : '')}
    ${ui.role === 'crear' && !editing ? `
      <div class="fragment__actions">
        <button class="btn btn--ghost btn--small" data-act="frag-edit" data-id="${f.id}">✏️ Editar</button>
        ${f.history.length ? `<button class="btn btn--ghost btn--small" data-act="frag-history" data-id="${f.id}">🕘 Historial (${f.history.length})</button>` : ''}
        <button class="btn btn--ghost btn--small danger-text" data-act="frag-del" data-id="${f.id}">🗑</button>
      </div>` : ''}
  </article>`;
}

/** Formulario para agregar un fragmento (texto, foto o audio). */
function composerHtml() {
  const c = ui.composer;
  const tab = (k, label) => `<button type="button" role="tab" aria-selected="${c.kind === k}" data-act="compose" data-kind="${k}">${label}</button>`;
  let inner = '';
  if (c.kind === 'text') {
    inner = `<div class="field"><label for="composer-text">Tu fragmento</label>
      <textarea id="composer-text" maxlength="4000" placeholder="¿Qué ocurre en este lugar? ¿Quién aparece?"></textarea>
      <div class="counter" id="composer-count" aria-live="polite">0 / 4000</div><span class="error" role="alert"></span></div>`;
  } else if (c.kind === 'photo') {
    inner = `<div class="field"><label for="composer-photo">Foto del lugar</label>
      <input type="file" id="composer-photo" accept="image/*" capture="environment">
      ${c.media ? `<img src="${c.media}" alt="Vista previa de la foto">` : ''}<span class="error" role="alert"></span></div>
      <div class="field"><label for="composer-text">Describe la foto</label>
      <textarea id="composer-text" maxlength="4000" style="min-height:70px" placeholder="Ayuda a personas con discapacidad visual y da contexto a la escena"></textarea></div>`;
  } else {
    inner = `<div class="field"><span><strong>Nota de voz</strong> (máx. ${MAX_AUDIO_SECONDS} s)</span>
      ${c.recording ? `<button type="button" class="btn btn--danger" data-act="rec-stop"><span class="rec-dot" aria-hidden="true"></span> Detener · <span id="rec-time">0 s</span></button>`
        : `<button type="button" class="btn btn--ghost" data-act="rec-start">🎙️ ${c.media ? 'Grabar de nuevo' : 'Empezar a grabar'}</button>`}
      ${c.media ? `<audio controls src="${c.media}"></audio>` : ''}<span class="error" role="alert"></span></div>
      <div class="field"><label for="composer-text">Transcripción o descripción (opcional)</label>
      <textarea id="composer-text" maxlength="4000" style="min-height:70px"></textarea></div>`;
  }
  return `<form class="composer" id="composer-form" novalidate>
    <div class="tabs" role="tablist" aria-label="Tipo de fragmento">${tab('text', '📝 Texto')}${tab('photo', '📷 Foto')}${tab('audio', '🎙️ Audio')}</div>
    ${inner}
    <p class="small muted">Se publicará como <strong>${esc(me()?.name || '')}</strong>. Tu borrador se guarda solo.</p>
    <div class="row" style="justify-content:flex-end">
      <button type="button" class="btn btn--ghost" data-act="compose-cancel">Cancelar</button>
      <button type="submit" class="btn">Publicar</button>
    </div>
  </form>`;
}

// ============================================================================
// 3. ACCIONES
// ============================================================================

/** Selecciona un nodo, lo centra en el mapa y abre su detalle. */
function selectNode(id, { focus = true } = {}) {
  ui.selectedId = id;
  ui.editing = null;
  if (ui.composer && ui.composer.nodeId !== id) closeComposer();
  const n = selectedNode();
  if (n && focus && mapView) mapView.focusNode(n);
  // Si el nodo es de un recorrido activo, la barra avanza hasta él.
  if (ui.walk) {
    const r = S().routes[ui.walk.routeId];
    const i = r?.nodeIds.indexOf(id);
    if (i >= 0) ui.walk.index = i;
  }
  expandPanel();
  render();
  $('#panel-body').scrollTop = 0;
}

/** Cambia de rol sin perder el lugar ni la vista del mapa (modelo mental espacial estable). */
function setRole(role, { announce = true } = {}) {
  if (ui.role === role) return;
  ui.role = role;
  prefs.role = role; savePrefs();
  setTool('idle');
  closeComposer();
  ui.editing = null;
  track('role', { to: role });
  render();
  if (announce) toast(role === 'crear' ? 'Modo Crear: ancla lugares, escribe y dibuja rutas.' : 'Modo Recorrer: camina la historia y desbloquea cada lugar.');
}

/** Activa/desactiva herramientas del modo Crear. */
function setTool(tool) {
  ui.tool = ui.tool === tool ? 'idle' : tool; // pulsar otra vez = desactivar
  if (ui.tool !== 'route') ui.draft = [];
  if (ui.tool !== 'idle') track('tool', { tool: ui.tool });
  render();
}

/** Diálogo para crear un nodo en la posición indicada. */
async function createNodeAt(latlng) {
  setTool('idle');
  const result = await openDialog(`
    <h2 id="dialog-title">Nuevo lugar de la historia</h2>
    <p class="muted small">Ubicación: ${latlng.lat.toFixed(5)}, ${latlng.lng.toFixed(5)}</p>
    <form id="node-form" novalidate>
      <div class="field"><label for="nf-title">Título de la escena *</label>
        <input type="text" id="nf-title" maxlength="80" autofocus placeholder="Ej.: La carta en la banca"><span class="error" role="alert"></span></div>
      <div class="field"><label for="nf-place">Nombre del lugar</label>
        <input type="text" id="nf-place" maxlength="80" placeholder="Ej.: Plaza de Barranco"></div>
      <div class="field"><label for="nf-text">Primer fragmento (opcional)</label>
        <textarea id="nf-text" maxlength="4000" placeholder="¿Qué ocurre aquí?"></textarea></div>
      <label class="checkbox"><input type="checkbox" id="nf-open" checked>
        <span>Invitar a otras personas a continuar la historia aquí<br><span class="small muted">Aparecerá en “Dónde puedes contribuir”.</span></span></label>
      <div class="dialog__actions"><button type="button" class="btn btn--ghost" data-close>Cancelar</button>
        <button type="submit" class="btn">📍 Anclar lugar</button></div>
    </form>`, (root, close) => {
    root.querySelector('#node-form').addEventListener('submit', e => {
      e.preventDefault();
      const title = root.querySelector('#nf-title');
      if (!title.value.trim()) { setFieldError(title, 'El título es obligatorio.'); track('error', { what: 'titulo-vacio' }); return; }
      close({ title: title.value, place: root.querySelector('#nf-place').value, text: root.querySelector('#nf-text').value.trim(), open: root.querySelector('#nf-open').checked });
    });
  });
  if (!result) return;
  const id = M.uid('n');
  const res = await run('node.create', { id, storyId: ui.storyId, lat: latlng.lat, lng: latlng.lng, title: result.title, place: result.place, open: result.open, code: M.randomCode() });
  if (!res.ok) return;
  if (result.text) await run('fragment.add', { nodeId: id, fragment: { id: M.uid('f'), kind: 'text', text: result.text } });
  track('success', { what: 'node.create' });
  selectNode(id);
  const node = S().nodes[id];
  toast(`Lugar anclado · código ${node.code}`, { type: 'ok', action: { label: 'Ver QR', fn: () => showNodeQr(node, ns => printQrSheet(ns, story().title)) } });
}

/** Crear nodo en la posición GPS actual (útil cuando la persona está en el sitio). */
function anchorHere() {
  if (!navigator.geolocation) { toast('Este navegador no da ubicación. Toca el mapa para anclar.', { type: 'error' }); return; }
  toast('Buscando tu ubicación…');
  navigator.geolocation.getCurrentPosition(
    p => createNodeAt({ lat: p.coords.latitude, lng: p.coords.longitude }),
    err => { track('error', { what: 'gps' }); toast(gpsErrorText(err) + ' Puedes tocar el mapa para anclar.', { type: 'error' }); },
    { enableHighAccuracy: true, timeout: 12000 }
  );
}

function gpsErrorText(err) {
  if (err.code === 1) return 'No diste permiso de ubicación.';
  if (err.code === 3) return 'El GPS tardó demasiado.';
  return 'No se pudo obtener tu ubicación (en el celular se necesita HTTPS).';
}

/** Agrega un nodo a la ruta en borrador. */
function addToDraft(id) {
  if (ui.draft.at(-1) === id) { toast('Ese lugar ya es la última parada. Toca otro pin.'); track('error', { what: 'ruta-repetido' }); return; }
  ui.draft.push(id);
  render();
}

async function saveRoute() {
  if (ui.draft.length < 2) { toast(M.ERROR_MESSAGES['ruta-corta'], { type: 'error' }); track('error', { what: 'ruta-corta' }); return; }
  const name = await openDialog(`
    <h2 id="dialog-title">Guardar ruta</h2>
    <p class="muted small">${ui.draft.length} paradas: ${ui.draft.map(id => esc(S().nodes[id].title)).join(' → ')}</p>
    <form id="route-form" novalidate><div class="field"><label for="rf-name">Nombre de la ruta *</label>
      <input type="text" id="rf-name" maxlength="60" autofocus value="Ruta de ${esc(me()?.name || '')}"><span class="error" role="alert"></span></div>
      <div class="dialog__actions"><button type="button" class="btn btn--ghost" data-close>Seguir editando</button><button class="btn">Guardar ruta</button></div></form>`,
  (root, close) => root.querySelector('#route-form').addEventListener('submit', e => {
    e.preventDefault();
    const input = root.querySelector('#rf-name');
    if (!input.value.trim()) { setFieldError(input, 'Ponle un nombre a la ruta.'); return; }
    close(input.value);
  }));
  if (!name) return;
  const res = await run('route.create', { id: M.uid('r'), storyId: ui.storyId, name, nodeIds: ui.draft, color: me()?.color });
  if (!res.ok) return;
  track('success', { what: 'route.create' });
  toast(`Ruta “${name}” guardada.`, { type: 'ok' });
  setTool('idle');
}

// ----------------------------------------------------------- Recorrido
function startWalk(routeId) {
  const r = S().routes[routeId];
  if (!r) return;
  if (ui.role !== 'recorrer') setRole('recorrer');
  const p = M.routeProgress(S(), store.userId, r);
  ui.walk = { routeId, index: p.nextIndex >= 0 ? p.nextIndex : 0 };
  ui.justFinished = null;
  startLocating(true);
  track('walk-start', { routeId });
  selectNode(r.nodeIds[ui.walk.index]);
}

function walkStep(delta) {
  const r = S().routes[ui.walk.routeId];
  const next = ui.walk.index + delta;
  if (next >= r.nodeIds.length) { // terminar
    const p = M.routeProgress(S(), store.userId, r);
    if (p.done < p.total) toast(`Te faltan ${p.total - p.done} lugar(es) por desbloquear. Puedes volver cuando quieras.`);
    else { ui.justFinished = r.id; track('success', { what: 'walk-complete' }); }
    render();
    return;
  }
  if (next < 0) return;
  ui.walk.index = next;
  selectNode(r.nodeIds[next]);
}

function exitWalk() {
  ui.walk = null;
  ui.justFinished = null;
  render();
}

/** Marca un nodo como leído (desbloqueado) e informa cómo se logró. */
async function unlock(node, via) {
  if (M.hasRead(S(), store.userId, node.id)) return;
  const res = await run('read.mark', { nodeId: node.id, via });
  if (!res.ok) return;
  const how = { qr: 'con el QR', codigo: 'con el código', gps: 'al llegar al lugar', remoto: '' }[via] || '';
  toast(`🔓 Desbloqueaste “${node.title}” ${how}`.trim(), { type: 'ok' });
  if (navigator.vibrate) navigator.vibrate(80); // retroalimentación háptica breve en el celular
  track('success', { what: 'unlock', via });
}

/** Abre el escáner o el campo de código y procesa el resultado. */
async function scan(startWith) {
  const walkRoute = ui.walk && S().routes[ui.walk.routeId];
  const expected = walkRoute ? S().nodes[walkRoute.nodeIds[ui.walk.index]] : selectedNode();
  const res = await openScanner({
    startWith,
    expected: ui.role === 'recorrer' ? expected : null,
    lookup: code => {
      const node = M.findNodeByCode(S(), code);
      return node ? { node } : { suggestions: M.suggestNodesByCode(S(), code) };
    }
  });
  if (!res) return;
  const { node, via } = res;
  if (node.storyId !== ui.storyId) switchStory(node.storyId, { fit: false });
  if (ui.role !== 'recorrer') setRole('recorrer', { announce: false });
  if (walkRoute && !walkRoute.nodeIds.includes(node.id)) toast(`“${node.title}” no está en la ruta que recorres, pero igual puedes leerlo.`);
  selectNode(node.id);
  await unlock(node, via);
}

// ----------------------------------------------------------------- GPS
/** Activa el seguimiento de ubicación (para desbloquear por cercanía). */
function startLocating(silent = false) {
  if (ui.watchId !== null) return;
  if (!navigator.geolocation) { if (!silent) toast('Este navegador no permite ubicación.', { type: 'error' }); return; }
  ui.watchId = navigator.geolocation.watchPosition(onPosition, err => {
    stopLocating();
    if (!silent) { toast(gpsErrorText(err) + ' Usa el QR o el código del lugar.', { type: 'error' }); track('error', { what: 'gps' }); }
  }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 });
  renderTopbar();
}

function stopLocating() {
  if (ui.watchId !== null) navigator.geolocation.clearWatch(ui.watchId);
  ui.watchId = null;
  ui.me = null;
  mapView?.showMe(null);
  renderTopbar();
  updateDistance();
}

function onPosition(p) {
  ui.me = { lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy };
  mapView?.showMe(ui.me);
  updateDistance();
  // Desbloqueo por cercanía: solo en Recorrer y para el nodo que se está viendo.
  const n = selectedNode();
  if (ui.role === 'recorrer' && n && !M.hasRead(S(), store.userId, n.id) && M.distanceMeters(ui.me, n) <= UNLOCK_RADIUS_M) unlock(n, 'gps');
}

/** Actualiza solo el texto de distancia (sin redibujar todo el panel en cada lectura GPS). */
function updateDistance() {
  const el = document.getElementById('dist-text');
  const n = selectedNode();
  if (!el || !n || !ui.me) return;
  const d = Math.round(M.distanceMeters(ui.me, n));
  el.textContent = d <= UNLOCK_RADIUS_M ? '¡Estás en el lugar!' : `Estás a ${d >= 1000 ? (d / 1000).toFixed(1) + ' km' : d + ' m'}. Se desbloquea a ${UNLOCK_RADIUS_M} m.`;
}

// ------------------------------------------------------- Fragmentos
const draftKey = id => `mr.draft.${id}`;
function loadDraft(nodeId) { try { return localStorage.getItem(draftKey(nodeId)) || ''; } catch { return ''; } }
function saveDraft(nodeId, text) { try { localStorage.setItem(draftKey(nodeId), text); } catch { /* sin espacio */ } }

function openComposer(kind) {
  const n = selectedNode();
  if (!n) return;
  if (ui.composer?.rec) ui.composer.rec.cancel();
  ui.composer = { nodeId: n.id, kind, media: ui.composer?.kind === kind ? ui.composer.media : null };
  renderPanel();
  $('#composer-text')?.focus();
}

function closeComposer() {
  ui.composer?.rec?.cancel();
  ui.composer = null;
}

async function publishFragment(form) {
  const c = ui.composer;
  const text = form.querySelector('#composer-text')?.value.trim() || '';
  const errEl = form.querySelector('.error');
  if (c.kind === 'text' && !text) { setFieldError(form.querySelector('#composer-text'), 'Escribe algo antes de publicar.'); track('error', { what: 'texto-vacio' }); return; }
  if (c.kind !== 'text' && !c.media) { errEl.textContent = c.kind === 'photo' ? 'Elige o toma una foto.' : 'Graba una nota de voz.'; track('error', { what: 'sin-archivo' }); return; }
  if (c.recording) { errEl.textContent = 'Detén la grabación antes de publicar.'; return; }
  const res = await run('fragment.add', { nodeId: c.nodeId, fragment: { id: M.uid('f'), kind: c.kind, text, media: c.media } });
  if (!res.ok) return;
  saveDraft(c.nodeId, '');
  closeComposer();
  ui.justFinished = null;
  track('success', { what: 'fragment.add' });
  toast('Fragmento publicado. ¡Gracias por continuar la historia!', { type: 'ok' });
  render();
}

/** Guarda la edición de un fragmento con control de versiones. */
async function saveEdit(nodeId, fragmentId, text, baseVersion) {
  const res = await run('fragment.edit', { nodeId, fragmentId, baseVersion, text });
  if (res.ok) {
    ui.editing = null;
    toast('Cambios guardados.', { type: 'ok' });
    track('success', { what: 'fragment.edit' });
    render();
    return;
  }
  if (res.error === 'conflicto') await resolveConflict(nodeId, res.conflict.current, text);
}

/**
 * CONFLICTO: dos personas editaron lo mismo. Se muestran ambas versiones lado
 * a lado y la persona decide (nadie pierde su trabajo en silencio).
 */
async function resolveConflict(nodeId, current, yourText) {
  track('conflict');
  const choice = await openDialog(`
    <h2 id="dialog-title">⚠️ ${esc(userOf(current.updatedBy).name)} editó este fragmento mientras escribías</h2>
    <p class="muted small">Elige qué versión conservar. Ninguna se pierde: la anterior queda en el historial.</p>
    <div class="compare">
      <div><h4>Versión actual · ${esc(userOf(current.updatedBy).name)} (v${current.version}, ${timeAgo(current.updatedAt)})</h4>${esc(current.text)}</div>
      <div><h4>Tu versión (sin guardar)</h4>${esc(yourText)}</div>
    </div>
    <div class="dialog__actions">
      <button class="btn btn--ghost" data-choice="theirs">Conservar la de ${esc(userOf(current.updatedBy).name)}</button>
      <button class="btn btn--ghost" data-choice="merge">Combinar y revisar</button>
      <button class="btn" data-choice="mine">Usar la mía</button>
    </div>`, (root, close) => root.querySelectorAll('[data-choice]').forEach(b => b.addEventListener('click', () => close(b.dataset.choice))));

  if (choice === 'mine') return saveEdit(nodeId, current.id, yourText, current.version);
  if (choice === 'merge') {
    // Se abre el editor con ambos textos para que la persona los fusione a mano.
    ui.selectedId = nodeId;
    ui.editing = { nodeId, fragmentId: current.id, baseVersion: current.version, text: `${current.text}\n\n— — —\n\n${yourText}` };
    render();
    $('#edit-text')?.focus();
    return;
  }
  // 'theirs' o cerrar: se descarta la edición propia
  ui.editing = null;
  render();
}

/** Historial de versiones de un fragmento, con opción de restaurar. */
async function showHistory(node, frag) {
  const versions = [...frag.history].reverse();
  const pick = await openDialog(`
    <h2 id="dialog-title">Historial del fragmento</h2>
    <p class="muted small">Versión actual: v${frag.version} por ${esc(userOf(frag.updatedBy).name)}</p>
    <ul class="list">${versions.map(h => `<li class="fragment">
      <div class="fragment__meta">v${h.version} · ${esc(userOf(h.by).name)} · ${timeAgo(h.at)}</div>
      <p class="fragment__text">${esc(h.text)}</p>
      <button class="btn btn--ghost btn--small" data-v="${h.version}">Restaurar esta versión</button></li>`).join('')}</ul>
    <div class="dialog__actions"><button class="btn btn--ghost" data-close>Cerrar</button></div>`,
  (root, close) => root.querySelectorAll('[data-v]').forEach(b => b.addEventListener('click', () => close(Number(b.dataset.v)))));
  if (!pick) return;
  const h = frag.history.find(x => x.version === pick);
  // Restaurar = una edición nueva con el texto antiguo (el historial se conserva).
  await saveEdit(node.id, frag.id, h.text, frag.version);
}

/** Borrado con "Deshacer" (más rápido que confirmar y igual de seguro). */
async function deleteWithUndo(type, payload, label, restoreType) {
  const res = await run(type, payload);
  if (!res.ok) return;
  render();
  toast(`${label} eliminado.`, { action: { label: 'Deshacer', fn: async () => { await run(restoreType, payload); render(); } } });
}

async function editNode(n) {
  const result = await openDialog(`
    <h2 id="dialog-title">Editar lugar</h2>
    <form id="ne-form" novalidate>
      <div class="field"><label for="ne-title">Título *</label><input type="text" id="ne-title" maxlength="80" value="${esc(n.title)}" autofocus><span class="error" role="alert"></span></div>
      <div class="field"><label for="ne-place">Nombre del lugar</label><input type="text" id="ne-place" maxlength="80" value="${esc(n.place)}"></div>
      <div class="dialog__actions"><button type="button" class="btn btn--ghost" data-close>Cancelar</button><button class="btn">Guardar</button></div>
    </form>`, (root, close) => root.querySelector('#ne-form').addEventListener('submit', e => {
    e.preventDefault();
    const t = root.querySelector('#ne-title');
    if (!t.value.trim()) { setFieldError(t, 'El título es obligatorio.'); return; }
    close({ title: t.value, place: root.querySelector('#ne-place').value });
  }));
  if (!result) return;
  const res = await run('node.update', { id: n.id, baseVersion: n.version, changes: result });
  if (res.error === 'conflicto') toast('Otra persona modificó este lugar justo antes. Revisa los cambios e inténtalo otra vez.', { type: 'error' });
  render();
}

async function moveNode(id, latlng) {
  const n = S().nodes[id];
  const prev = { lat: n.lat, lng: n.lng };
  const res = await run('node.update', { id, baseVersion: n.version, changes: latlng });
  if (res.error === 'conflicto') toast('Otra persona modificó este lugar. Se restauró su posición.', { type: 'error' });
  render();
  if (res.ok) toast('Lugar movido.', { action: { label: 'Deshacer', fn: async () => { await run('node.update', { id, changes: prev }); render(); } } });
}

// --------------------------------------------------------- Historias y usuarios
function switchStory(id, { fit = true } = {}) {
  ui.storyId = id;
  prefs.storyId = id; savePrefs();
  ui.selectedId = null; ui.walk = null; ui.draft = []; ui.tool = 'idle';
  closeComposer();
  if (fit && mapView) mapView.fitStory(nodes(), story()?.center);
  render();
}

async function storyDialog() {
  const list = Object.values(S().stories);
  const result = await openDialog(`
    <h2 id="dialog-title">Historias</h2>
    <ul class="list">${list.map(s => `<li><button class="list-item" data-story="${s.id}" ${s.id === ui.storyId ? 'aria-current="true"' : ''}>
      <span class="list-item__main"><strong>${esc(s.title)}</strong><span>${M.activeNodes(S(), s.id).length} lugares · por ${esc(userOf(s.createdBy).name)}</span></span>
      ${s.id === ui.storyId ? '<span class="badge badge--ok">Abierta</span>' : ''}</button></li>`).join('')}</ul>
    <h3>Nueva historia</h3>
    <form id="sf-form" novalidate>
      <div class="field"><label for="sf-title">Título *</label><input type="text" id="sf-title" maxlength="80"><span class="error" role="alert"></span></div>
      <div class="field"><label for="sf-desc">Premisa (opcional)</label><textarea id="sf-desc" maxlength="400" style="min-height:70px" placeholder="¿De qué trata? Ayuda a otros a sumarse."></textarea></div>
      <p class="small muted">Empezará en la zona que ves ahora en el mapa.</p>
      <div class="dialog__actions"><button type="button" class="btn btn--ghost" data-close>Cerrar</button><button class="btn">Crear historia</button></div>
    </form>`, (root, close) => {
    root.querySelectorAll('[data-story]').forEach(b => b.addEventListener('click', () => close({ open: b.dataset.story })));
    root.querySelector('#sf-form').addEventListener('submit', e => {
      e.preventDefault();
      const t = root.querySelector('#sf-title');
      if (!t.value.trim()) { setFieldError(t, 'Ponle un título a la historia.'); return; }
      close({ create: { title: t.value, description: root.querySelector('#sf-desc').value } });
    });
  });
  if (!result) return;
  if (result.open) return switchStory(result.open);
  const id = M.uid('s');
  const res = await run('story.create', { id, ...result.create, center: mapView?.center() || null });
  if (res.ok) { switchStory(id, { fit: false }); setRole('crear'); toast('Historia creada. Ancla el primer lugar.', { type: 'ok' }); }
}

/** Elegir o crear autor. Con `intro` se muestra la bienvenida (onboarding). */
async function userDialog({ intro = false } = {}) {
  const users = Object.values(S().users);
  const result = await openDialog(`
    <h2 id="dialog-title">${intro ? 'Bienvenida a Mapa de Relatos' : '¿Quién está escribiendo?'}</h2>
    ${intro ? `<div class="onboard">
      <div class="onboard__step"><span aria-hidden="true">🗺️</span><div><strong>El mapa es la historia.</strong><br><span class="small">Cada pin es una escena anclada a un lugar real.</span></div></div>
      <div class="onboard__step"><span aria-hidden="true">✍️</span><div><strong>Crear:</strong> ancla lugares, escribe fragmentos y une rutas.</div></div>
      <div class="onboard__step"><span aria-hidden="true">🚶</span><div><strong>Recorrer:</strong> camina la ruta, escanea el QR de cada lugar y continúa la historia.</div></div>
    </div>` : ''}
    ${users.length && !intro ? `<ul class="list">${users.map(u => `<li><button class="list-item" data-user="${u.id}">${avatar(u)}
      <span class="list-item__main"><strong>${esc(u.name)}</strong></span>${u.id === store.userId ? '<span class="badge badge--ok">Tú</span>' : ''}</button></li>`).join('')}</ul>
      <p class="small muted">Cambiar de autor en el mismo dispositivo sirve para las pruebas con varios participantes.</p><h3>Nuevo autor</h3>` : ''}
    <form id="uf-form" novalidate>
      <div class="field"><label for="uf-name">Tu nombre o seudónimo *</label>
        <input type="text" id="uf-name" maxlength="40" autofocus autocomplete="nickname"><span class="help">Aparecerá junto a lo que escribas (atribución).</span><span class="error" role="alert"></span></div>
      <fieldset class="field"><legend><strong>Tu color</strong></legend><div class="color-row">
        ${M.AUTHOR_COLORS.map((c, i) => `<label><input type="radio" name="color" value="${c}" ${i === users.length % M.AUTHOR_COLORS.length ? 'checked' : ''}><span style="background:${c}"></span><span class="sr-only">Color ${i + 1}</span></label>`).join('')}
      </div></fieldset>
      <div class="dialog__actions">${intro ? '' : '<button type="button" class="btn btn--ghost" data-close>Cancelar</button>'}<button class="btn">${intro ? 'Empezar' : 'Crear autor'}</button></div>
    </form>`, (root, close) => {
    root.querySelectorAll('[data-user]').forEach(b => b.addEventListener('click', () => close({ id: b.dataset.user })));
    root.querySelector('#uf-form').addEventListener('submit', e => {
      e.preventDefault();
      const name = root.querySelector('#uf-name');
      if (!name.value.trim()) { setFieldError(name, 'Escribe un nombre para firmar tus aportes.'); return; }
      close({ name: name.value, color: new FormData(e.target).get('color') });
    });
  });
  if (!result) {
    if (!store.userId) return userDialog({ intro }); // se necesita un autor para continuar
    return;
  }
  if (result.id) {
    store.userId = result.id;
  } else {
    const id = M.uid('u');
    store.userId = id; // necesario antes del dispatch
    const res = await run('user.upsert', { id, name: result.name, color: result.color });
    if (!res.ok) { store.userId = prefs.userId || null; return; }
  }
  prefs.userId = store.userId; prefs.onboarded = true; savePrefs();
  render();
  toast(`Escribiendo como ${me()?.name}.`, { type: 'ok' });
}

function nodeListDialog() {
  openDialog(`
    <h2 id="dialog-title">Lugares de “${esc(story()?.title || '')}”</h2>
    <p class="small muted">Vista alternativa al mapa (útil con lector de pantalla o sin señal).</p>
    ${nodeList(nodes())}
    <div class="dialog__actions"><button class="btn btn--ghost" data-close>Cerrar</button></div>`,
  (root, close) => root.querySelectorAll('[data-act="select"]').forEach(b => b.addEventListener('click', () => { close(); selectNode(b.dataset.id); })));
}

function helpDialog() {
  openDialog(`
    <h2 id="dialog-title">Ayuda</h2>
    <h3>Pines del mapa</h3>
    <ul class="small">
      <li><strong>Crear:</strong> azul = lugar · naranja = invita a continuar · el número = cantidad de fragmentos.</li>
      <li><strong>Recorrer:</strong> gris “?” = por descubrir · verde “✓” = leído · número = orden en la ruta.</li>
    </ul>
    <h3>Desbloquear un lugar</h3>
    <ul class="small"><li>Llega al lugar con “Mi ubicación” activada (a ${UNLOCK_RADIUS_M} m).</li>
      <li>Escanea su QR (o súbele una foto).</li><li>Escribe el código de 4 caracteres impreso bajo el QR.</li></ul>
    <h3>Atajos de teclado</h3>
    <ul class="small"><li><kbd>N</kbd> anclar nodo · <kbd>R</kbd> dibujar ruta (modo Crear)</li><li><kbd>Esc</kbd> cancelar herramienta o cerrar</li></ul>
    <div class="dialog__actions"><button class="btn btn--ghost" data-act-intro>Ver bienvenida</button><button class="btn" data-close>Entendido</button></div>`,
  (root, close) => root.querySelector('[data-act-intro]').addEventListener('click', () => { close(); userDialog({ intro: true }); }));
}

// ----------------------------------------------------------- Panel móvil
function expandPanel() {
  const p = $('#panel');
  if (p.classList.contains('is-collapsed')) { p.classList.remove('is-collapsed'); document.body.classList.remove('panel-collapsed'); setTimeout(() => mapView?.refreshSize(), 260); }
}
function cyclePanel() {
  const p = $('#panel');
  // normal → expandido → plegado → normal
  if (p.classList.contains('is-expanded')) { p.classList.replace('is-expanded', 'is-collapsed'); }
  else if (p.classList.contains('is-collapsed')) { p.classList.remove('is-collapsed'); }
  else p.classList.add('is-expanded');
  const collapsed = p.classList.contains('is-collapsed');
  document.body.classList.toggle('panel-collapsed', collapsed);
  $('#panel-grip').setAttribute('aria-expanded', String(!collapsed));
  setTimeout(() => mapView?.refreshSize(), 260);
}

// ============================================================================
// 4. EVENTOS
// ============================================================================
function bindEvents() {
  // --- Barra superior ---
  $('#role-crear').addEventListener('click', () => setRole('crear'));
  $('#role-recorrer').addEventListener('click', () => setRole('recorrer'));
  $('#btn-story').addEventListener('click', storyDialog);
  $('#btn-user').addEventListener('click', () => userDialog());
  const menu = $('#menu');
  const toggleMenu = open => { menu.hidden = !open; $('#btn-menu').setAttribute('aria-expanded', String(open)); if (open) menu.querySelector('button').focus(); };
  $('#btn-menu').addEventListener('click', e => { e.stopPropagation(); toggleMenu(menu.hidden); });
  document.addEventListener('click', e => { if (!menu.hidden && !menu.contains(e.target)) toggleMenu(false); });
  menu.addEventListener('keydown', e => {
    // Navegación con flechas dentro del menú (patrón ARIA "menu")
    const items = [...menu.querySelectorAll('button')];
    const i = items.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); items[(i + 1) % items.length].focus(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); items[(i - 1 + items.length) % items.length].focus(); }
    if (e.key === 'Escape') { toggleMenu(false); $('#btn-menu').focus(); }
  });

  // Acciones del menú (y del botón de respaldo del mapa)
  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-action]');
    if (!b) return;
    toggleMenu(false);
    switch (b.dataset.action) {
      case 'list': nodeListDialog(); break;
      case 'print':
        if (!nodes().length) toast('Esta historia no tiene lugares para imprimir.', { type: 'error' });
        else printQrSheet(nodes(), story().title);
        break;
      case 'test': openTestPanel(); break;
      case 'export': downloadText(`mapa-de-relatos-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(S(), null, 2)); break;
      case 'import':
        if (store.mode === 'server') toast('La importación solo está disponible en modo local (para no sobrescribir los datos compartidos).', { type: 'error' });
        else $('#import-file').click();
        break;
      case 'help': helpDialog(); break;
      case 'reset':
        if (await confirmDialog({ title: '¿Restablecer la demo?', body: store.mode === 'server' ? 'Se borrarán los datos compartidos de TODOS los participantes y se cargará la historia de ejemplo.' : 'Se borrarán los datos de este navegador y se cargará la historia de ejemplo.', confirm: 'Restablecer', danger: true })) {
          await store.reset();
          ui.selectedId = null; ui.walk = null;
          switchStory('s_barranco');
          toast('Demo restablecida.', { type: 'ok' });
        }
        break;
    }
  });
  $('#import-file').addEventListener('change', async e => {
    const file = e.target.files[0];
    if (!file) return;
    try { store.importState(JSON.parse(await file.text())); switchStory(Object.keys(S().stories)[0]); toast('Datos importados.', { type: 'ok' }); }
    catch (err) { toast(`No se pudo importar: ${err.message}`, { type: 'error' }); }
    e.target.value = '';
  });

  // --- Herramientas ---
  $('#tool-anchor').addEventListener('click', () => setTool('anchor'));
  $('#tool-route').addEventListener('click', () => setTool('route'));
  $('#tool-anchor-gps').addEventListener('click', anchorHere);
  $('#tool-scan').addEventListener('click', () => scan('camera'));
  $('#tool-code').addEventListener('click', () => scan('code'));
  $('#tool-locate').addEventListener('click', () => (ui.watchId === null ? startLocating() : stopLocating()));
  $('#route-undo').addEventListener('click', () => { ui.draft.pop(); render(); });
  $('#route-cancel').addEventListener('click', () => setTool('idle'));
  $('#route-save').addEventListener('click', saveRoute);
  $('#walk-prev').addEventListener('click', () => walkStep(-1));
  $('#walk-next').addEventListener('click', () => walkStep(1));
  $('#walk-exit').addEventListener('click', exitWalk);
  $('#panel-grip').addEventListener('click', cyclePanel);

  // --- Panel: delegación de eventos (un solo listener para todos los botones) ---
  const panel = $('#panel-body');
  panel.addEventListener('click', async e => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const n = selectedNode();
    const frag = n && b.dataset.id ? n.fragments.find(f => f.id === b.dataset.id) : null;
    switch (b.dataset.act) {
      case 'back': ui.selectedId = null; closeComposer(); ui.editing = null; render(); break;
      case 'select': selectNode(b.dataset.id); break;
      case 'walk': startWalk(b.dataset.id); break;
      case 'route-del': deleteWithUndo('route.delete', { id: b.dataset.id }, 'Ruta', 'route.restore'); break;
      case 'start-anchor': setTool('anchor'); break;
      case 'scan': scan('camera'); break;
      case 'code': scan('code'); break;
      case 'read-remote': unlock(n, 'remoto').then(render); break;
      case 'compose': openComposer(b.dataset.kind); break;
      case 'compose-cancel': closeComposer(); render(); break;
      case 'rec-start': {
        if (!AudioRecorder.isSupported()) { toast('Este navegador no permite grabar audio.', { type: 'error' }); break; }
        const rec = new AudioRecorder(s => { const t = document.getElementById('rec-time'); if (t) t.textContent = `${s} s`; });
        try {
          await rec.start();
          ui.composer.rec = rec; ui.composer.recording = true; renderPanel();
          // Si llega al máximo, se detiene sola y se muestra el resultado.
          const auto = setInterval(async () => { if (rec.seconds >= MAX_AUDIO_SECONDS) { clearInterval(auto); await finishRecording(); } }, 500);
          ui.composer.autoTimer = auto;
        } catch (err) {
          track('error', { what: 'microfono' });
          toast(err.name === 'NotAllowedError' ? 'No diste permiso para usar el micrófono.' : 'No se pudo usar el micrófono (en el celular se necesita HTTPS).', { type: 'error' });
        }
        break;
      }
      case 'rec-stop': await finishRecording(); break;
      case 'frag-edit': ui.editing = { nodeId: n.id, fragmentId: frag.id, baseVersion: frag.version, text: frag.text }; renderPanel(); $('#edit-text')?.focus(); break;
      case 'edit-cancel': ui.editing = null; renderPanel(); break;
      case 'frag-history': showHistory(n, frag); break;
      case 'frag-del': deleteWithUndo('fragment.delete', { nodeId: n.id, fragmentId: frag.id }, 'Fragmento', 'fragment.restore'); break;
      case 'node-edit': editNode(n); break;
      case 'node-qr': showNodeQr(n, ns => printQrSheet(ns, story().title)); break;
      case 'node-open': await run('node.update', { id: n.id, changes: { open: !n.open } }); render(); break;
      case 'node-del': ui.selectedId = null; deleteWithUndo('node.delete', { id: n.id }, `Lugar “${n.title}”`, 'node.restore'); break;
    }
  });

  panel.addEventListener('submit', e => {
    e.preventDefault();
    if (e.target.id === 'composer-form') publishFragment(e.target);
    if (e.target.id === 'edit-form') {
      const ta = e.target.querySelector('#edit-text');
      const frag = S().nodes[e.target.dataset.node]?.fragments.find(f => f.id === e.target.dataset.frag);
      if (frag?.kind === 'text' && !ta.value.trim()) { setFieldError(ta, 'El texto no puede quedar vacío.'); track('error', { what: 'texto-vacio' }); return; }
      saveEdit(e.target.dataset.node, e.target.dataset.frag, ta.value, ui.editing.baseVersion);
    }
  });

  panel.addEventListener('input', e => {
    if (e.target.id === 'composer-text' && ui.composer) {
      saveDraft(ui.composer.nodeId, e.target.value); // autoguardado del borrador
      const c = document.getElementById('composer-count');
      if (c) c.textContent = `${e.target.value.length} / 4000`;
      e.target.setAttribute('aria-invalid', 'false');
    }
    if (e.target.id === 'edit-text' && ui.editing) ui.editing.text = e.target.value;
  });

  panel.addEventListener('change', async e => {
    if (e.target.id !== 'composer-photo') return;
    const file = e.target.files[0];
    if (!file) return;
    try {
      ui.composer.media = await compressImage(file);
      renderPanel();
    } catch {
      toast('No se pudo leer la imagen. Prueba con otra.', { type: 'error' });
      track('error', { what: 'foto' });
    }
  });

  // --- Teclado ---
  document.addEventListener('keydown', e => {
    if ($('#dialog').open) return;
    const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName);
    if (e.key === 'Escape') {
      if (ui.tool !== 'idle') setTool('idle');
      else if (ui.composer) { closeComposer(); render(); }
      else if (ui.selectedId) { ui.selectedId = null; render(); }
      return;
    }
    if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
    if (ui.role === 'crear' && e.key.toLowerCase() === 'n') setTool('anchor');
    if (ui.role === 'crear' && e.key.toLowerCase() === 'r') setTool('route');
  });

  // --- Store ---
  store.addEventListener('change', e => {
    render({ remote: e.detail.remote });
    // Conciencia de colaboración: avisar lo que hicieron otras personas.
    e.detail.newLog.filter(l => l.type !== 'read.mark' && l.type !== 'user.upsert').slice(-2)
      .forEach(l => toast(describeLog(l).replace(/<[^>]+>/g, ''), { type: 'info' }));
  });
  store.addEventListener('status', e => {
    const { mode, online, pending } = e.detail;
    const chip = $('#sync-chip');
    if (mode === 'local') { chip.className = 'chip chip--local'; chip.textContent = '● Guardado en este navegador'; }
    else if (!online) { chip.className = 'chip chip--warn'; chip.textContent = `⚠ Sin conexión${pending ? ` · ${pending} pendiente(s)` : ''}`; }
    else { chip.className = 'chip chip--ok'; chip.textContent = '● Compartido en línea'; }
    chip.title = mode === 'local' ? 'No hay servidor: los cambios se guardan solo aquí.' : 'Los cambios se comparten con todos.';
  });
  store.addEventListener('conflict', e => {
    const c = e.detail.conflict;
    if (c?.entity === 'fragment') resolveConflict(c.nodeId, c.current, c.yours.text);
    else toast('Un cambio hecho sin conexión chocó con otro más reciente y no se aplicó.', { type: 'error' });
  });
}

async function finishRecording() {
  const c = ui.composer;
  if (!c?.rec) return;
  clearInterval(c.autoTimer);
  c.media = await c.rec.stop();
  c.rec = null; c.recording = false;
  renderPanel();
}

// ============================================================================
// 5. ARRANQUE
// ============================================================================
async function init() {
  bindEvents();

  // Mapa (si Leaflet cargó). Si no, se muestra la alternativa de lista.
  if (MapView.isAvailable()) {
    mapView = new MapView($('#map'), {
      onNodeClick: id => {
        if (ui.tool === 'route') return addToDraft(id);
        if (ui.tool === 'anchor') { toast('Ya hay un lugar aquí. Toca un punto libre del mapa.'); return; }
        selectNode(id, { focus: false });
      },
      onMapClick: latlng => {
        if (ui.tool === 'anchor') return createNodeAt(latlng);
        if (ui.tool === 'route') { toast('Para la ruta, toca los pines (lugares), no el mapa.'); track('error', { what: 'ruta-click-mapa' }); }
      },
      onNodeMoved: moveNode
    });
  } else {
    $('#map-fallback').hidden = false;
  }

  await store.init();
  store.userId = prefs.userId && S().users[prefs.userId] ? prefs.userId : null;
  if (!story()) ui.storyId = Object.keys(S().stories)[0] || null;
  mapView?.fitStory(nodes(), story()?.center);
  render();

  // Primera visita: bienvenida + nombre (necesario para la atribución).
  if (!store.userId) await userDialog({ intro: true });

  // Enlace profundo desde un QR escaneado con la cámara del celular: ?n=CÓDIGO
  const code = new URLSearchParams(location.search).get('n');
  if (code) {
    history.replaceState(null, '', location.pathname); // limpia la URL
    const node = M.findNodeByCode(S(), code);
    if (node) {
      if (node.storyId !== ui.storyId) switchStory(node.storyId, { fit: false });
      setRole('recorrer', { announce: false });
      selectNode(node.id);
      await unlock(node, 'qr');
    } else {
      toast(`El código “${code}” no se encontró. Revisa e intenta escribirlo.`, { type: 'error' });
      scan('code');
    }
  }
}

init();
