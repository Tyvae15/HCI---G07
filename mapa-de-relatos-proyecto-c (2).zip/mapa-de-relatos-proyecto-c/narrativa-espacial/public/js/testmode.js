/**
 * testmode.js — MODO "PRUEBA DE USABILIDAD" PARA EL ENTREGABLE 2 (Sección 6)
 * ----------------------------------------------------------------------------
 * Herramienta para el FACILITADOR (no para el participante). Registra:
 *   • Efectividad: resultado de la tarea (éxito / parcial / fracaso) → % de éxito
 *   • Eficiencia: tiempo por tarea + errores (manuales y automáticos*)
 *   • Satisfacción: SEQ (1–7) por tarea y SUS (10 ítems) por participante
 *   • Notas cualitativas del protocolo Think-Aloud
 * Todo se exporta a CSV para analizarlo en Excel/SPSS/R (descriptiva e inferencial).
 *
 * *Errores automáticos: la app emite eventos 'mr:track' con kind:'error' cuando
 *  el participante comete un error detectable (validación fallida, código no
 *  encontrado, cámara denegada…). Se cuentan mientras la tarea está en curso.
 */
import { esc, openDialog, toast, downloadText } from './ui.js';

const LS_KEY = 'mr.tests.v1';

/** Escenarios de tarea (task scenarios). Ajústenlos a sus preguntas de investigación. */
export const TASKS = [
  { id: 'T1', title: 'Anclar un nodo con un fragmento', scenario: 'Estás en la historia “Ecos de Barranco”. Crea un nuevo lugar de la historia en cualquier esquina del mapa, ponle un título y escribe un primer fragmento.' },
  { id: 'T2', title: 'Dibujar una ruta', scenario: 'Une tres lugares de la historia en el orden en que deberían leerse y guarda esa ruta con un nombre.' },
  { id: 'T3', title: 'Recorrer una ruta', scenario: 'Cambia a modo lectura y recorre “La ruta de la carta”. Desbloquea los dos primeros lugares.' },
  { id: 'T4', title: 'Abrir un lugar con QR dañado', scenario: 'El QR del Puente de los Suspiros está roto. Abre ese lugar usando el código impreso: BRC3 (está mal copiado a propósito).' },
  { id: 'T5', title: 'Continuar la historia mientras lees', scenario: 'Mientras recorres la ruta, agrega una continuación en el último lugar, sin salir del recorrido.' },
  { id: 'T6', title: 'Resolver un conflicto de edición', scenario: 'Edita el primer fragmento de “La carta en la banca”. (El facilitador edita el mismo fragmento en otra pestaña antes de que guardes.)' }
];

/** Ítems del System Usability Scale (Brooke, 1996), versión en español. */
export const SUS_ITEMS = [
  'Creo que me gustaría usar este sistema con frecuencia.',
  'Encontré el sistema innecesariamente complejo.',
  'Pensé que el sistema era fácil de usar.',
  'Creo que necesitaría el apoyo de un técnico para poder usar este sistema.',
  'Encontré que las funciones del sistema estaban bien integradas.',
  'Pensé que había demasiada inconsistencia en el sistema.',
  'Imagino que la mayoría de las personas aprendería a usar este sistema muy rápido.',
  'Encontré el sistema muy engorroso de usar.',
  'Me sentí muy seguro/a usando el sistema.',
  'Necesité aprender muchas cosas antes de poder empezar con este sistema.'
];

/**
 * Puntaje SUS (0–100): ítems impares aportan (respuesta − 1), pares (5 − respuesta);
 * la suma se multiplica por 2.5.
 */
export function susScore(answers) {
  const sum = answers.reduce((acc, v, i) => acc + (i % 2 === 0 ? v - 1 : 5 - v), 0);
  return sum * 2.5;
}

/** Interpretación adjetiva (Bangor, Kortum y Miller, 2009). 68 ≈ promedio de la industria. */
export function susAdjective(score) {
  if (score >= 85.5) return 'Excelente';
  if (score >= 71.4) return 'Bueno';
  if (score >= 50.9) return 'Aceptable';
  if (score >= 35.7) return 'Pobre';
  return 'Inaceptable';
}

// --------------------------------------------------------------- Persistencia
function load() {
  try { return JSON.parse(localStorage.getItem(LS_KEY)) || { trials: [], sus: [] }; }
  catch { return { trials: [], sus: [] }; }
}
function save(data) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(data)); } catch { toast('No se pudo guardar la prueba en el navegador.', { type: 'error' }); }
}

const mean = xs => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : NaN);
const sd = xs => {
  if (xs.length < 2) return NaN;
  const m = mean(xs);
  return Math.sqrt(xs.reduce((a, b) => a + (b - m) ** 2, 0) / (xs.length - 1));
};
const fmt = (x, d = 1) => (Number.isFinite(x) ? x.toFixed(d) : '—');
const csvCell = v => `"${String(v ?? '').replace(/"/g, '""')}"`;

// ---------------------------------------------------------------- Ejecución
let running = null; // {participant, taskId, start, errorsAuto, errorsManual, events:[]}
let tick = null;

// Cuenta errores automáticos mientras hay una tarea en curso.
window.addEventListener('mr:track', e => {
  if (!running) return;
  running.events.push(e.detail.kind + (e.detail.what ? ':' + e.detail.what : ''));
  if (e.detail.kind === 'error') { running.errorsAuto += 1; renderBar(); }
});

function renderBar() {
  const bar = document.getElementById('test-bar');
  if (!running) { bar.hidden = true; return; }
  const secs = Math.round((Date.now() - running.start) / 1000);
  const mm = String(Math.floor(secs / 60)).padStart(2, '0');
  const ss = String(secs % 60).padStart(2, '0');
  bar.hidden = false;
  bar.innerHTML = `
    <span>🧪 ${esc(running.participant)} · ${esc(running.taskId)}</span>
    <time aria-label="Tiempo">${mm}:${ss}</time>
    <span title="Errores manuales + automáticos">Err: ${running.errorsManual}+${running.errorsAuto}</span>
    <button id="tb-err" style="background:#fbbf24">+ Error</button>
    <button id="tb-end" style="background:#4ade80">Terminar</button>`;
  bar.querySelector('#tb-err').onclick = () => { running.errorsManual += 1; renderBar(); };
  bar.querySelector('#tb-end').onclick = finishTask;
}

function startTask(participant, taskId) {
  running = { participant, taskId, start: Date.now(), errorsAuto: 0, errorsManual: 0, events: [] };
  clearInterval(tick);
  tick = setInterval(renderBar, 1000);
  renderBar();
}

/** Al terminar: el facilitador registra resultado, SEQ y notas Think-Aloud. */
async function finishTask() {
  const r = running;
  const duration = Math.round((Date.now() - r.start) / 1000);
  running = null;
  clearInterval(tick);
  renderBar();
  const task = TASKS.find(t => t.id === r.taskId);
  const result = await openDialog(`
    <h2 id="dialog-title">Resultado de ${esc(r.taskId)}</h2>
    <p class="muted small">${esc(task?.title)} · ${duration} s · errores: ${r.errorsManual} manuales + ${r.errorsAuto} automáticos</p>
    <form id="res-form">
      <fieldset class="field"><legend><strong>Efectividad</strong></legend>
        <label class="checkbox"><input type="radio" name="res" value="exito" required> Éxito (sin ayuda)</label>
        <label class="checkbox"><input type="radio" name="res" value="parcial"> Éxito parcial / con ayuda</label>
        <label class="checkbox"><input type="radio" name="res" value="fallo"> Fracaso / abandonó</label>
      </fieldset>
      <fieldset class="field"><legend><strong>SEQ:</strong> “En general, esta tarea fue…” (1 = muy difícil, 7 = muy fácil)</legend>
        <div class="likert">${[1, 2, 3, 4, 5, 6, 7].map(v => `<label><input type="radio" name="seq" value="${v}">${v}</label>`).join('')}</div>
      </fieldset>
      <div class="field"><label for="res-notes">Notas Think-Aloud (citas, dudas, desvíos)</label>
        <textarea id="res-notes" name="notes" placeholder="Ej.: “No sé si ya se guardó…” — buscó el botón en el panel"></textarea></div>
      <div class="dialog__actions">
        <button type="button" class="btn btn--ghost" data-close>Descartar</button>
        <button type="submit" class="btn">Guardar intento</button>
      </div>
    </form>`, (root, close) => {
    root.querySelector('#res-form').addEventListener('submit', e => {
      e.preventDefault();
      const f = new FormData(e.target);
      if (!f.get('res')) { toast('Marca el resultado de la tarea.', { type: 'error' }); return; }
      close({ result: f.get('res'), seq: Number(f.get('seq')) || null, notes: f.get('notes') || '' });
    });
  });
  if (!result) { toast('Intento descartado.'); return; }
  const data = load();
  data.trials.push({
    participant: r.participant, taskId: r.taskId, startedAt: new Date(r.start).toISOString(),
    durationSec: duration, result: result.result, errorsManual: r.errorsManual, errorsAuto: r.errorsAuto,
    seq: result.seq, notes: result.notes, events: r.events.join(' | ')
  });
  save(data);
  toast(`Intento de ${r.taskId} guardado.`, { type: 'ok' });
}

// ------------------------------------------------------------- Panel principal
export function openTestPanel(tab = 'tarea') {
  const data = load();
  const tabs = { tarea: 'Tarea', sus: 'SUS', resultados: 'Resultados' };
  let body = '';

  if (tab === 'tarea') {
    body = `
      <p class="muted small">Lee el escenario en voz alta, pulsa “Iniciar” y entrega el dispositivo. Una barra pequeña mostrará el tiempo.</p>
      <form id="t-form">
        <div class="field"><label for="t-part">ID del participante</label>
          <input type="text" id="t-part" placeholder="P01" required value="${esc(localStorage.getItem('mr.lastParticipant') || '')}"></div>
        <div class="field"><label for="t-task">Tarea</label>
          <select id="t-task">${TASKS.map(t => `<option value="${t.id}">${t.id} · ${esc(t.title)}</option>`).join('')}</select></div>
        <div class="field"><label>Escenario para leer al participante</label>
          <p id="t-scn" class="invite-box" style="margin:0">${esc(TASKS[0].scenario)}</p></div>
        <div class="dialog__actions">
          <button type="button" class="btn btn--ghost" data-close>Cerrar</button>
          <button type="submit" class="btn" ${running ? 'disabled' : ''}>▶ Iniciar tarea</button>
        </div>
      </form>`;
  } else if (tab === 'sus') {
    body = `
      <p class="muted small">Se aplica al final de la sesión. 1 = Totalmente en desacuerdo · 5 = Totalmente de acuerdo.</p>
      <form id="sus-form">
        <div class="field"><label for="sus-part">ID del participante</label>
          <input type="text" id="sus-part" required value="${esc(localStorage.getItem('mr.lastParticipant') || '')}"></div>
        ${SUS_ITEMS.map((q, i) => `
          <fieldset class="sus-item"><legend>${i + 1}. ${esc(q)}</legend>
            <div class="likert">${[1, 2, 3, 4, 5].map(v => `<label><input type="radio" name="q${i}" value="${v}" required>${v}</label>`).join('')}</div>
          </fieldset>`).join('')}
        <div class="dialog__actions">
          <button type="button" class="btn btn--ghost" data-close>Cerrar</button>
          <button type="submit" class="btn">Calcular y guardar SUS</button>
        </div>
      </form>`;
  } else {
    // Resumen descriptivo por tarea y del SUS.
    const rows = TASKS.map(t => {
      const tr = data.trials.filter(x => x.taskId === t.id);
      if (!tr.length) return `<tr><td>${t.id}</td><td colspan="5" class="muted">sin datos</td></tr>`;
      const success = tr.reduce((a, x) => a + (x.result === 'exito' ? 1 : x.result === 'parcial' ? 0.5 : 0), 0) / tr.length;
      const times = tr.filter(x => x.result !== 'fallo').map(x => x.durationSec);
      const errs = tr.map(x => x.errorsManual + x.errorsAuto);
      const seqs = tr.map(x => x.seq).filter(Boolean);
      return `<tr><td>${t.id}</td><td>${tr.length}</td><td>${fmt(success * 100, 0)}%</td>
        <td>${fmt(mean(times))} ± ${fmt(sd(times))}</td><td>${fmt(mean(errs))}</td><td>${fmt(mean(seqs))}</td></tr>`;
    }).join('');
    const scores = data.sus.map(s => s.score);
    body = `
      <table class="table">
        <thead><tr><th>Tarea</th><th>n</th><th>% éxito*</th><th>Tiempo s (M ± DE)**</th><th>Errores (M)</th><th>SEQ (M)</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <p class="small muted">*Parcial cuenta 0.5. **Solo intentos no fallidos.</p>
      <h3>SUS</h3>
      <p>n = ${scores.length} · Media = <strong>${fmt(mean(scores))}</strong> (${Number.isFinite(mean(scores)) ? susAdjective(mean(scores)) : '—'}) · DE = ${fmt(sd(scores))}
        <br><span class="small muted">Referencia: 68 = usabilidad promedio.</span></p>
      <div class="dialog__actions">
        <button class="btn btn--ghost" id="t-clear">Borrar datos</button>
        <button class="btn btn--ghost" id="t-csv-trials">⬇️ CSV tareas</button>
        <button class="btn" id="t-csv-sus">⬇️ CSV SUS</button>
      </div>`;
  }

  openDialog(`
    <h2 id="dialog-title">🧪 Prueba de usabilidad</h2>
    <div class="tabs" role="tablist">${Object.entries(tabs).map(([k, v]) =>
      `<button role="tab" data-tab="${k}" aria-selected="${k === tab}">${v}</button>`).join('')}</div>
    ${body}`, (root, close) => {
    root.querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => openTestPanel(b.dataset.tab)));

    const tForm = root.querySelector('#t-form');
    if (tForm) {
      const sel = root.querySelector('#t-task');
      sel.addEventListener('change', () => { root.querySelector('#t-scn').textContent = TASKS.find(t => t.id === sel.value).scenario; });
      tForm.addEventListener('submit', e => {
        e.preventDefault();
        const p = root.querySelector('#t-part').value.trim();
        if (!p) { toast('Escribe el ID del participante.', { type: 'error' }); return; }
        localStorage.setItem('mr.lastParticipant', p);
        close();
        startTask(p, sel.value);
      });
    }

    const susForm = root.querySelector('#sus-form');
    if (susForm) {
      susForm.addEventListener('submit', e => {
        e.preventDefault();
        const f = new FormData(susForm);
        const answers = SUS_ITEMS.map((_, i) => Number(f.get(`q${i}`)));
        if (answers.some(v => !v)) { toast('Faltan respuestas del SUS.', { type: 'error' }); return; }
        const p = root.querySelector('#sus-part').value.trim() || 'sin-id';
        const score = susScore(answers);
        const d = load();
        d.sus.push({ participant: p, answers, score, at: new Date().toISOString() });
        save(d);
        toast(`SUS de ${p}: ${score} (${susAdjective(score)})`, { type: 'ok' });
        openTestPanel('resultados');
      });
    }

    root.querySelector('#t-csv-trials')?.addEventListener('click', () => {
      const head = ['participante', 'tarea', 'inicio', 'tiempo_s', 'resultado', 'errores_manuales', 'errores_auto', 'seq', 'notas', 'eventos'];
      const lines = load().trials.map(t => [t.participant, t.taskId, t.startedAt, t.durationSec, t.result, t.errorsManual, t.errorsAuto, t.seq, t.notes, t.events].map(csvCell).join(','));
      downloadText('pruebas_tareas.csv', '﻿' + [head.join(','), ...lines].join('\n'), 'text/csv');
    });
    root.querySelector('#t-csv-sus')?.addEventListener('click', () => {
      const head = ['participante', ...SUS_ITEMS.map((_, i) => `q${i + 1}`), 'sus', 'adjetivo', 'fecha'];
      const lines = load().sus.map(s => [s.participant, ...s.answers, s.score, susAdjective(s.score), s.at].map(csvCell).join(','));
      downloadText('pruebas_sus.csv', '﻿' + [head.join(','), ...lines].join('\n'), 'text/csv');
    });
    root.querySelector('#t-clear')?.addEventListener('click', () => {
      save({ trials: [], sus: [] });
      toast('Datos de prueba borrados.');
      openTestPanel('resultados');
    });
  });
}
